# Awtad Engineering Constitution

- Treat source-backed facts, verified web facts, engineering decisions, and proposals as separate categories.
- Never invent government APIs, credentials, regulatory rules, or product behavior.
- Never use secrets from source documents; environment variables are the only secret boundary.
- Enforce tenant isolation on the server for every query and mutation.
- Privileged mutations require authorization and audit logging.
- Keep business rules outside React components.
- Workflow, notification, permission, and audit capabilities are shared platform primitives.
- Attendance calculations must be deterministic and unit-testable.
- Arabic and RTL are first-class requirements.
- Do not mark an unfinished module as complete.
