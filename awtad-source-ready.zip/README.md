# Awtad Platform

Enterprise HR/HCM foundation for the Awtad product.

## Local setup

Requirements: Node.js 20.9+ for Next.js; the current repository targets Next.js 16.3.8. PostgreSQL 17 is used by the local compose file.

```bash
cp .env.example .env
npm install
docker compose up -d
npm run db:migrate
npm run db:seed
npm run dev
```

Open `http://localhost:3000`.

Demo credentials created by the seed script:
- Email: `admin@awtad.local`
- Password: `ChangeMe!123`

Change the demo password before using any shared environment.

## Security

No production credentials are required by this codebase. Environment variables are placeholders only. Do not commit `.env` files.

## Architecture

See `docs/PHASE-0-1.md` and `docs/SOURCE-TRACEABILITY.md`.
