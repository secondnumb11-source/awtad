# Source traceability

| Capability | Basis | Status |
|---|---|---|
| Employee master data | Supplied Awtad specification + manager guide | Implemented foundation |
| Manager users and permissions | Manager guide | Data model foundation |
| Attendance events | Attendance guide | Data model foundation |
| Shifts | Attendance guide | Data model foundation |
| Work locations | Attendance + notifications guides | Data model foundation |
| Manual attendance/request processing | Manual control guide | Data model foundation |
| Notifications targeted to users/locations | Notifications guide | Data model foundation |
| Audit trail | Awtad specification | Data model foundation |
| Multi-tenant architecture | Engineering decision for enterprise product | Implemented foundation |
| RBAC/ABAC direction | Engineering decision informed by manager guide | RBAC foundation; ABAC next |
