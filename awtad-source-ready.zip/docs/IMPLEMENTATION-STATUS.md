# Awtad implementation status

## Written in source
- Foundation: tenant, users, roles, permissions, signed sessions, audit.
- Core HR: employees, organizations, assignments, benefits, documents foundation.
- Workforce: shifts, shift assignments, locations, attendance events, geofence validation, leave request foundation, manager scopes.
- Workflow: request creation/decision and audit trail.
- Payroll: compensation, periods, runs, items and calculation foundation.
- Saudi compliance foundation: expiring employee compliance documents and rule evaluation.
- Talent: vacancies, candidates, applications, matching, goals, learning, skills.
- Finance: expenses/travel request boundaries, assets and integration connections.
- Notifications: persistent notification service.
- Analytics: event tracking and workforce snapshot.
- AI: permission-aware tool gateway and AI audit trail.

## Not claimed as externally verified
- Any government API endpoint or credentialed integration.
- Banking, ERP, insurance or third-party service credentials.
- Market salary datasets.
- Production deployment or penetration-test results.
- Runtime build verification in this environment; package installation timed out.

## Next source stages
- Full employee lifecycle and contract/onboarding rules.
- Complete attendance rule engine and recurring schedule evaluator.
- Full leave balances/accruals and attachment verification.
- Saudi payroll statutory calculations after official specifications are sourced.
- Recruitment pipeline, interview integrations and candidate document parsing.
- Performance cycles/360 and learning paths/compliance reporting.
- Expense OCR adapter boundary, reimbursement and accounting journal engine.
- Workflow designer, conditional routing, delegation and SLA/escalation.
- Mobile application source.
- Test suite, observability, security hardening and deployment configuration.

## Automated continuation — current build batch

Added source modules for:
- employee lifecycle events, contracts, onboarding, offboarding
- leave balances and leave transactions
- daily attendance evaluation and persisted daily records
- final settlement/EOSB calculation boundary
- configurable statutory payroll calculation primitives and provider-neutral statutory adapters
- accounting chart/journal posting and trial balance
- workflow instances/tasks, task completion and overdue escalation
- compliance case management
- recruitment interviews and scoring
- performance reviewer/360 aggregation
- learning paths and progress recalculation
- engagement/eNPS calculation and metrics
- provider-neutral OCR and travel booking adapters

Validation performed in the source environment:
- Node syntax checks passed for migration/seed scripts.
- Local relative-import resolution check found no missing local imports after correction.
- Full TypeScript/build validation remains unverified because project dependencies are not installed in the source environment.


## Latest automated build stage
- Added configurable leave policy rules and carryover validation.
- Added EOSB calculation boundary and payslip composition helpers.
- Added workflow task authorization checks.
- Split attendance calculation from database orchestration for isolated testing.
- Added security redaction helper for audit/AI payloads.
- Added dashboard views for payroll, leave, recruitment, performance, finance, compliance and workflows.
- Added core rule tests runnable with Node's TypeScript stripping support.
- Runtime/build completion is not claimed because project dependencies are not installed in this source-only environment.
