# Awtad verification contract

`npm run verify` is the release gate. It requires dependencies to be installed and then runs the full test suite, TypeScript, and the production build.

Preferred installation:

```bash
npm ci
npm run verify
```

If `package-lock.json` is not present, run `npm install` once in a networked environment and commit the generated lockfile; subsequent environments should use `npm ci`.

No production credentials are required for static verification. Database-dependent operations must use explicitly supplied test configuration.
