# Awtad automated staged build

The implementation is intentionally staged, but execution does not depend on user confirmation between stages.

1. Foundation: tenant, identity, auth, permissions, audit, database conventions.
2. Core HR: employees, organization, assignments, documents, benefits.
3. Workforce: shifts, schedules, locations, attendance, exceptions, leave, manager scopes.
4. Workflow: requests, approvals, delegation, notifications, audit.
5. Payroll/compliance: compensation, payroll periods/runs, EOSB foundation, compliance documents and rule engine.
6. Talent: vacancies, candidates, applications, matching, performance, goals, learning, skills.
7. Finance: expenses, travel, assets, reimbursement and integration boundaries.
8. Intelligence: analytics events, AI audit, permission-aware AI tool boundary.
9. Enterprise hardening: tests, observability, migrations, security, deployment manifests.

A stage is only considered verified when the relevant code is present and the available static/runtime checks pass. External government APIs, bank APIs, ERP credentials and third-party AI credentials are integration dependencies and are not fabricated.
