# أوتاد — Phase 0/1 Engineering Record

## Source basis
- `awtad HR platform describtion(1).docx`: master product scope supplied by the client.
- Four supplied Dawmt guide PDFs: attendance management, notifications, manual control/request processing, manager platform.
- External verification: Next.js official docs/release notes were checked on 2026-10-07. Next.js 16.3.8 is the current Active LTS patch referenced by the official September 30, 2026 security release.

## Non-negotiable engineering rules
1. No assumption is represented as a verified fact.
2. Government integrations are implemented only from verified official API/specification material.
3. No credentials or secrets are committed to source code.
4. Tenant isolation is enforced server-side; UI filtering is never a security boundary.
5. Every privileged mutation must be auditable.
6. Business rules belong in domain/application services, not React components.
7. Workflows are reusable infrastructure, not per-screen approval logic.
8. Attendance calculations are deterministic and testable independently of UI.
9. Historical employment state must remain queryable for payroll/audit use cases.
10. Arabic/RTL is a first-class product requirement, not a later localization pass.

## Phase 1 implemented in this repository
- PostgreSQL schema for tenant, users, roles, permissions, organizations, employees, locations, shifts, attendance events, requests, notifications, audit logs.
- Secure HTTP-only signed session cookie.
- Password hashing using Node's `scrypt` implementation.
- Server-side tenant context from session.
- Permission model primitives.
- Login/logout/health APIs.
- Dashboard.
- Employee directory.
- Navigation placeholders for attendance, requests, notifications, and manager platform.
- Seed data for local development.

## Explicitly not claimed as complete
The current code is the first production-oriented foundation slice, not the complete Awtad product. Payroll, Saudi compliance integrations, full workflow designer, ATS, AI platform, mobile app, finance, and enterprise hardening remain subsequent implementation phases.
