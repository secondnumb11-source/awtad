import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const hash = (value) => createHash('sha256').update(JSON.stringify(value)).digest('hex');
assert.equal(hash({ a: 1 }), hash({ a: 1 }));
assert.notEqual(hash({ a: 1 }), hash({ a: 2 }));
assert.match('x-request-id', /^x-/);
console.log('api rules: ok');
