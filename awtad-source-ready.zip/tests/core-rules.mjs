import assert from 'node:assert/strict';
import {calculateCarryover, validateLeaveDuration} from '../modules/leave/policy.ts';
import {calculateEosb} from '../modules/payroll/eosb.ts';
import {buildPayslip} from '../modules/payroll/payslip.ts';
import {redactObject} from '../modules/security/redaction.ts';
import {evaluateAttendance} from '../modules/attendance/calculator.ts';
import {canCompleteWorkflowTask} from '../modules/workflow/authorization.ts';

assert.equal(calculateCarryover(8,{annualEntitlement:30,carryoverLimit:5,minimumUnit:1}),5);
assert.equal(calculateEosb({monthlyBasic:10000,serviceYears:6,reason:'termination',rule:{firstFiveYearsFactor:1,afterFiveYearsFactor:1}}),35000);
assert.deepEqual(buildPayslip({employeeId:'e',basic:10000,allowances:1000,overtime:500,deductions:300}),{employeeId:'e',gross:11500,deductions:300,net:11200,employerContributions:0});
assert.deepEqual(redactObject({password:'x',profile:{token:'y',name:'A'}}),{password:'[REDACTED]',profile:{token:'[REDACTED]',name:'A'}});
assert.equal(validateLeaveDuration(2,{annualEntitlement:30,carryoverLimit:5,minimumUnit:0.5}),true);
console.log('core rules: ok');

const attendance=evaluateAttendance({start_time:'22:00',end_time:'06:00',break_minutes:30,grace_in_minutes:10,grace_out_minutes:10,crosses_midnight:true},new Date('2026-01-01T22:15:00'),new Date('2026-01-02T06:30:00'));
assert.equal(attendance.lateMinutes,5); assert.equal(attendance.overtimeMinutes,15);
assert.equal(canCompleteWorkflowTask({taskStatus:'pending',taskAssigneeUserId:'u1',taskAssigneeEmployeeId:null,userId:'u1'}),true);
assert.equal(canCompleteWorkflowTask({taskStatus:'pending',taskAssigneeUserId:'u1',taskAssigneeEmployeeId:null,userId:'u2'}),false);
