import assert from 'node:assert/strict';
import fs from 'node:fs';

const schema = fs.readFileSync(new URL('../db/schema.sql', import.meta.url), 'utf8');
const requiredTables = [
  'tenants','users','roles','permissions','role_permissions','user_roles','organizations','employees',
  'attendance_events','requests','notifications','audit_logs','leave_balances','payroll_runs','payroll_items',
  'documents','document_versions','document_signatures','workflow_definitions','workflow_tasks',
  'api_idempotency_keys','api_request_logs','security_events','ai_knowledge_documents','ai_knowledge_chunks',
];
for (const table of requiredTables) {
  assert.match(schema, new RegExp(`CREATE TABLE IF NOT EXISTS ${table}\\s*\\(`), `missing table ${table}`);
}
assert.match(schema, /role_permissions\s*\([\s\S]*permission_id TEXT NOT NULL REFERENCES permissions\(code\)/);
assert.match(schema, /CREATE INDEX IF NOT EXISTS idx_api_idempotency_expiry/);
assert.match(schema, /CREATE INDEX IF NOT EXISTS idx_api_request_logs_tenant_created/);
console.log(`db integrity: ok (${requiredTables.length} required tables checked)`);
