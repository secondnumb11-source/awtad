import assert from 'node:assert/strict';

const source = await import('../lib/config.ts');
assert.throws(() => source.getConfig({}), /DATABASE_URL/);
assert.throws(() => source.getConfig({DATABASE_URL:'postgres://db', SESSION_SECRET:'short'}), /SESSION_SECRET/);
const config = source.getConfig({DATABASE_URL:'postgres://db', SESSION_SECRET:'12345678901234567890123456789012', NODE_ENV:'test'});
assert.equal(config.NODE_ENV, 'test');
console.log('config rules: ok');
