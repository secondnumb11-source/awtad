import fs from 'node:fs/promises';

const middleware = await fs.readFile(new URL('../middleware.ts', import.meta.url), 'utf8');
if (/from\s+['"]node:/.test(middleware)) {
  throw new Error('middleware imports a Node-only module; middleware must remain Edge-runtime compatible');
}
if (!middleware.includes('globalThis.crypto.randomUUID()')) {
  throw new Error('middleware must use Web Crypto randomUUID for request IDs');
}
console.log('edge runtime rules: ok');
