import crypto from 'node:crypto';
import { cookies } from 'next/headers';
import { safeEqualText } from './security';

const COOKIE = 'awtad_session';
const TTL_SECONDS = 60 * 60 * 8;
type Session = { userId: string; tenantId: string; email: string; exp: number };
function secret() { const value = process.env.SESSION_SECRET; if (!value) throw new Error('SESSION_SECRET is required'); return value; }
function sign(payload: string) { return crypto.createHmac('sha256', secret()).update(payload).digest('base64url'); }
export function encodeSession(session: Omit<Session, 'exp'>) {
  const payload = Buffer.from(JSON.stringify({ ...session, exp: Math.floor(Date.now()/1000)+TTL_SECONDS })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}
export function decodeSession(value: string): Session | null {
  const [payload, signature] = value.split('.'); if (!payload || !signature || !safeEqualText(signature, sign(payload))) return null;
  try { const session = JSON.parse(Buffer.from(payload,'base64url').toString('utf8')) as Session; return session.exp > Math.floor(Date.now()/1000) ? session : null; } catch { return null; }
}
export async function getSession() { const store=await cookies(); const value=store.get(COOKIE)?.value; return value ? decodeSession(value) : null; }
export async function setSession(session: Omit<Session,'exp'>) { const store=await cookies(); store.set(COOKIE, encodeSession(session), {httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',path:'/',maxAge:TTL_SECONDS}); }
export async function clearSession() { const store=await cookies(); store.set(COOKIE,'',{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',path:'/',maxAge:0}); }
