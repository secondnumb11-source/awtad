import crypto from 'node:crypto';
import { NextResponse } from 'next/server';
import { query } from './db';

export function requestId(request: Request) {
  return request.headers.get('x-request-id') || crypto.randomUUID();
}

export function jsonError(error: unknown, status = 400, id?: string) {
  return NextResponse.json({ error: error instanceof Error ? error.message : 'Invalid request', requestId: id }, { status, headers: id ? { 'x-request-id': id } : undefined });
}

export function jsonOk<T>(data: T, status = 200, id?: string) {
  return NextResponse.json(data, { status, headers: id ? { 'x-request-id': id } : undefined });
}

export function bodyHash(body: unknown) {
  return crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex');
}

export async function getIdempotentResponse(args: { tenantId: string; userId: string; key?: string; requestHash: string }) {
  if (!args.key) return null;
  const r = await query<{ response_status: number; response_body: unknown; request_hash: string; expires_at: string }>(
    `SELECT response_status,response_body,request_hash,expires_at FROM api_idempotency_keys WHERE tenant_id=$1 AND user_id=$2 AND idempotency_key=$3`,
    [args.tenantId, args.userId, args.key],
  );
  const row = r.rows[0];
  if (!row) return null;
  if (new Date(row.expires_at).getTime() <= Date.now()) return null;
  if (row.request_hash !== args.requestHash) throw new Error('Idempotency-Key was already used with a different request payload');
  return { status: row.response_status, body: row.response_body };
}

export async function saveIdempotentResponse(args: { tenantId: string; userId: string; key?: string; requestHash: string; status: number; body: unknown; ttlHours?: number }) {
  if (!args.key) return;
  const ttlHours = args.ttlHours ?? 24;
  await query(
    `INSERT INTO api_idempotency_keys(tenant_id,user_id,idempotency_key,request_hash,response_status,response_body,expires_at)
     VALUES($1,$2,$3,$4,$5,$6,now()+($7 || ' hours')::interval)
     ON CONFLICT(tenant_id,user_id,idempotency_key) DO NOTHING`,
    [args.tenantId,args.userId,args.key,args.requestHash,args.status,args.body,ttlHours],
  );
}

export async function logApiRequest(args: { tenantId?: string; userId?: string; requestId: string; method: string; route: string; statusCode?: number; durationMs?: number; metadata?: Record<string, unknown> }) {
  await query(
    `INSERT INTO api_request_logs(tenant_id,user_id,request_id,method,route,status_code,duration_ms,metadata) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,
    [args.tenantId ?? null,args.userId ?? null,args.requestId,args.method,args.route,args.statusCode ?? null,args.durationMs ?? null,args.metadata ?? {}],
  );
}
