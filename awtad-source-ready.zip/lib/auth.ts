import { redirect } from 'next/navigation';
import { getSession } from './session';
import { query } from './db';

export async function requireSession(): Promise<NonNullable<Awaited<ReturnType<typeof getSession>>>> { const session=await getSession(); if(!session) { redirect('/login'); throw new Error('Unauthenticated'); } return session; }
export async function hasPermission(userId:string, tenantId:string, permission:string) {
  const r=await query<{allowed:boolean}>(`SELECT EXISTS(SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id JOIN role_permissions rp ON rp.role_id=r.id WHERE ur.user_id=$1 AND r.tenant_id=$2 AND rp.permission_id=$3) allowed`,[userId,tenantId,permission]);
  return r.rows[0]?.allowed ?? false;
}
export async function requirePermission(userId:string,tenantId:string,permission:string) { if(!(await hasPermission(userId,tenantId,permission))) throw new Error(`Forbidden: ${permission}`); }
