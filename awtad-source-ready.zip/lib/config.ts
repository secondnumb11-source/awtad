export type AwtadConfig = {
  NODE_ENV: 'development' | 'test' | 'production';
  DATABASE_URL: string;
  SESSION_SECRET: string;
  AWTAD_SEED_ADMIN_PASSWORD?: string;
};

export function getConfig(env: NodeJS.ProcessEnv = process.env): AwtadConfig {
  const nodeEnv = env.NODE_ENV ?? 'development';
  if (!['development', 'test', 'production'].includes(nodeEnv)) throw new Error('Invalid NODE_ENV');
  if (!env.DATABASE_URL) throw new Error('DATABASE_URL is required');
  if (!env.SESSION_SECRET || env.SESSION_SECRET.length < 32) throw new Error('SESSION_SECRET must be at least 32 characters');
  if (env.AWTAD_SEED_ADMIN_PASSWORD !== undefined && env.AWTAD_SEED_ADMIN_PASSWORD.length < 12) {
    throw new Error('AWTAD_SEED_ADMIN_PASSWORD must be at least 12 characters when supplied');
  }
  return {
    NODE_ENV: nodeEnv as AwtadConfig['NODE_ENV'],
    DATABASE_URL: env.DATABASE_URL,
    SESSION_SECRET: env.SESSION_SECRET,
    ...(env.AWTAD_SEED_ADMIN_PASSWORD ? { AWTAD_SEED_ADMIN_PASSWORD: env.AWTAD_SEED_ADMIN_PASSWORD } : {}),
  };
}
