import { query } from './db';

export async function getDashboard(tenantId: string) {
  const [employees, pending, notifications] = await Promise.all([
    query<{ count: string }>('SELECT count(*) FROM employees WHERE tenant_id=$1 AND employment_status=\'active\'', [tenantId]),
    query<{ count: string }>('SELECT count(*) FROM requests WHERE tenant_id=$1 AND status=\'pending\'', [tenantId]),
    query<{ count: string }>('SELECT count(*) FROM notifications WHERE tenant_id=$1 AND read_at IS NULL', [tenantId])
  ]);
  return { employees: Number(employees.rows[0].count), pendingRequests: Number(pending.rows[0].count), unreadNotifications: Number(notifications.rows[0].count) };
}

export async function listEmployees(tenantId: string) {
  const result = await query(`SELECT e.id, e.employee_number, e.first_name, e.last_name, e.first_name_ar, e.last_name_ar, e.email, e.employment_status, o.name_ar AS organization_name FROM employees e LEFT JOIN organizations o ON o.id=e.organization_id WHERE e.tenant_id=$1 ORDER BY e.created_at DESC`, [tenantId]);
  return result.rows;
}
