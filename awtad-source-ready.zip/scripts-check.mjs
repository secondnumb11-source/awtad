import fs from 'node:fs/promises';
import path from 'node:path';

const root = new URL('.', import.meta.url);
const rootPath = new URL(root).pathname;
const files = [];
async function walk(dir) {
  for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
    if (['node_modules','.next','.git'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) await walk(full);
    else if (/\.(ts|tsx|mjs)$/.test(entry.name)) files.push(full);
  }
}
await walk(rootPath);
let errors = 0;
for (const file of files) {
  const source = await fs.readFile(file, 'utf8');
  if (/TODO\s*:\s*FIXME/.test(source)) {
    console.error(`forbidden FIXME marker: ${file}`);
    errors++;
  }
}
if (errors) process.exit(1);
console.log(`source hygiene: ok (${files.length} source files scanned)`);
