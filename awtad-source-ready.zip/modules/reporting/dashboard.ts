import { query } from '../../lib/db';
export async function workforceSnapshot(tenantId:string){
 const r=await query(`SELECT (SELECT count(*) FROM employees WHERE tenant_id=$1 AND employment_status='active') active_employees,(SELECT count(*) FROM requests WHERE tenant_id=$1 AND status='pending') pending_requests,(SELECT count(*) FROM notifications WHERE tenant_id=$1 AND read_at IS NULL) unread_notifications,(SELECT count(*) FROM compliance_documents WHERE tenant_id=$1 AND expires_at < CURRENT_DATE + INTERVAL '30 days') compliance_due_30d`,[tenantId]);
 return r.rows[0];
}
