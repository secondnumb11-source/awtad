import { query } from '../../lib/db';

export type DataScope = { organizationIds?: string[]; employeeIds?: string[]; includeDescendants?: boolean };
export async function getUserDataScope(userId:string, tenantId:string):Promise<DataScope>{
  const r=await query<{organization_id:string|null;employee_id:string|null}>(`SELECT ms.organization_id,ms.employee_id FROM manager_scopes ms WHERE ms.user_id=$1 AND ms.tenant_id=$2`,[userId,tenantId]);
  return {organizationIds:r.rows.flatMap((x: {organization_id:string|null;employee_id:string|null})=>x.organization_id?[x.organization_id]:[],employeeIds:r.rows.flatMap((x: {organization_id:string|null;employee_id:string|null})=>x.employee_id?[x.employee_id]:[])};
}
export function scopePredicate(alias:string, scope:DataScope, start=1){
  const clauses:string[]=[]; const values:unknown[]=[]; let i=start;
  if(scope.employeeIds?.length){ clauses.push(`${alias}.id = ANY($${i++}::uuid[])`); values.push(scope.employeeIds); }
  if(scope.organizationIds?.length){ clauses.push(`${alias}.organization_id = ANY($${i++}::uuid[])`); values.push(scope.organizationIds); }
  return {sql:clauses.length?`(${clauses.join(' OR ')})`:'TRUE',values};
}
