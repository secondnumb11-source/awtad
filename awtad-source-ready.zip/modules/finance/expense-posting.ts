import { createExpenseJournal } from '../accounting/journal';
import { query } from '../../lib/db';
export async function postApprovedExpense(args:{tenantId:string;expenseId:string;expenseAccountId:string;payableAccountId:string;entryNumber:string;entryDate:string}){
  const r=await query<{amount:string;employee_id:string|null;description:string|null;status:string}>(`SELECT amount,employee_id,description,status FROM expenses WHERE id=$1 AND tenant_id=$2`,[args.expenseId,args.tenantId]);
  if(!r.rowCount) throw new Error('Expense not found'); if(r.rows[0].status!=='approved') throw new Error('Only approved expenses can be posted');
  return createExpenseJournal({tenantId:args.tenantId,entryNumber:args.entryNumber,entryDate:args.entryDate,expenseAccountId:args.expenseAccountId,cashOrPayableAccountId:args.payableAccountId,amount:Number(r.rows[0].amount),employeeId:r.rows[0].employee_id??undefined,description:r.rows[0].description??undefined});
}
