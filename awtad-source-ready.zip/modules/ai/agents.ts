import { query, withTransaction } from '../../lib/db';
import { auditAiAction } from './audit';
import type { AiModelProvider, ModelRequest } from './provider';
export async function runAgent(args:{tenantId:string;userId?:string;agentCode:string;input:Record<string,unknown>;provider:AiModelProvider;request:Omit<ModelRequest,'messages'> & {messages:ModelRequest['messages']}}){
 const r=await query<{id:string}>(`INSERT INTO ai_agent_runs(tenant_id,user_id,agent_code,status,input) VALUES($1,$2,$3,'running',$4) RETURNING id`,[args.tenantId,args.userId??null,args.agentCode,args.input]);
 try{const result=await args.provider.generate(args.request);await query(`UPDATE ai_agent_runs SET status='completed',output=$1,completed_at=now() WHERE id=$2 AND tenant_id=$3`,[{text:result.text,usage:result.usage??{},finishReason:result.finishReason??null},r.rows[0].id,args.tenantId]);await auditAiAction({tenantId:args.tenantId,userId:args.userId,agent:args.agentCode,action:'agent.completed',input:args.input,outputSummary:result.text.slice(0,2000)});return result;}
 catch(error){const message=error instanceof Error?error.message:'Unknown AI error';await query(`UPDATE ai_agent_runs SET status='failed',error=$1,completed_at=now() WHERE id=$2 AND tenant_id=$3`,[message,r.rows[0].id,args.tenantId]);throw error;}
}
