import { query, withTransaction } from '../../lib/db';
import { createHash } from 'node:crypto';
export function contentChecksum(content:string){return createHash('sha256').update(content).digest('hex');}
export function splitIntoChunks(content:string,maxChars=1800){const clean=content.replace(/\s+/g,' ').trim();if(!clean)return [];const out:string[]=[];for(let i=0;i<clean.length;i+=maxChars)out.push(clean.slice(i,i+maxChars));return out;}
export async function indexKnowledgeDocument(args:{tenantId:string;title:string;sourceType:string;sourceKey?:string;content:string;metadata?:Record<string,unknown>}){
 return withTransaction(async client=>{
  const checksum=contentChecksum(args.content);
  const existing=await client.query<{id:string}>(`SELECT id FROM ai_knowledge_documents WHERE tenant_id=$1 AND checksum=$2 LIMIT 1`,[args.tenantId,checksum]);
  if(existing.rowCount)return existing.rows[0].id;
  const d=await client.query<{id:string}>(`INSERT INTO ai_knowledge_documents(tenant_id,title,source_type,source_key,checksum,content,metadata) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,[args.tenantId,args.title,args.sourceType,args.sourceKey??null,checksum,args.content,args.metadata??{}]);
  for(const [i,chunk] of splitIntoChunks(args.content).entries()) await client.query(`INSERT INTO ai_knowledge_chunks(tenant_id,document_id,chunk_index,content,metadata) VALUES($1,$2,$3,$4,$5)`,[args.tenantId,d.rows[0].id,i,chunk,args.metadata??{}]);
  return d.rows[0].id;
 });
}
export async function lexicalRetrieve(args:{tenantId:string;queryText:string;limit?:number}){
 const q=args.queryText.trim(); if(!q)return [];
 const terms=q.split(/\s+/).filter(Boolean).slice(0,12);
 const pattern=`%${terms.join('%')}%`;
 const r=await query(`SELECT kc.id,kc.document_id,kc.content,kc.metadata,kd.title,kd.source_type FROM ai_knowledge_chunks kc JOIN ai_knowledge_documents kd ON kd.id=kc.document_id WHERE kc.tenant_id=$1 AND (kc.content ILIKE $2 OR kd.title ILIKE $2) ORDER BY kd.updated_at DESC,kc.chunk_index LIMIT $3`,[args.tenantId,pattern,Math.min(Math.max(args.limit??8,1),50)]);
 return r.rows;
}
