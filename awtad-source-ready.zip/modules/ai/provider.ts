export type ChatMessage={role:'system'|'user'|'assistant'|'tool';content:string};
export type ModelRequest={model:string;messages:ChatMessage[];temperature?:number;maxTokens?:number;tools?:Array<Record<string,unknown>>};
export type ModelResponse={text:string;finishReason?:string;usage?:Record<string,number>;raw?:unknown};
export interface AiModelProvider { readonly provider:string; generate(request:ModelRequest):Promise<ModelResponse>; }
export class UnconfiguredAiModelProvider implements AiModelProvider {
 constructor(public readonly provider='unconfigured'){}
 async generate(_request:ModelRequest):Promise<ModelResponse>{throw new Error(`AI model provider ${this.provider} is not configured`);}
}
