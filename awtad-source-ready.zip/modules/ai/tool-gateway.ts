import { hasPermission } from '../../lib/auth';
import { auditAiAction } from './audit';

export type AiTool = {name:string;permission:string;execute:(args:Record<string,unknown>)=>Promise<unknown>};
const tools=new Map<string,AiTool>();
export function registerAiTool(tool:AiTool){tools.set(tool.name,tool);}
export async function executeAiTool(args:{tenantId:string;userId:string;toolName:string;input:Record<string,unknown>}){
 const tool=tools.get(args.toolName); if(!tool) throw new Error('AI tool not found');
 if(!(await hasPermission(args.userId,args.tenantId,tool.permission))) throw new Error('AI tool permission denied');
 await auditAiAction({tenantId:args.tenantId,userId:args.userId,agent:'awtad-ai',action:'tool.execute',input:args.input,toolName:tool.name});
 const output=await tool.execute(args.input);
 await auditAiAction({tenantId:args.tenantId,userId:args.userId,agent:'awtad-ai',action:'tool.result',outputSummary:JSON.stringify(output).slice(0,2000),toolName:tool.name});
 return output;
}
