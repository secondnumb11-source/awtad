import { query } from '../../lib/db';

export async function addDocumentVersion(args:{tenantId:string;documentId:string;storageKey:string;checksum:string;mimeType:string;createdBy?:string}) {
  const current=await query<{next:number}>(`SELECT COALESCE(MAX(version_no),0)+1 AS next FROM document_versions WHERE tenant_id=$1 AND document_id=$2`,[args.tenantId,args.documentId]);
  const version=current.rows[0].next;
  const r=await query<{id:string}>(`INSERT INTO document_versions(tenant_id,document_id,version_no,storage_key,checksum,mime_type,created_by) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,[args.tenantId,args.documentId,version,args.storageKey,args.checksum,args.mimeType,args.createdBy??null]);
  return {id:r.rows[0].id,version};
}
export async function listDocumentVersions(tenantId:string,documentId:string){
  const r=await query(`SELECT id,version_no,storage_key,checksum,mime_type,created_by,created_at FROM document_versions WHERE tenant_id=$1 AND document_id=$2 ORDER BY version_no DESC`,[tenantId,documentId]);
  return r.rows;
}
