import { createHash } from 'node:crypto';
import { query } from '../../lib/db';

export function checksum(buffer:Buffer){return createHash('sha256').update(buffer).digest('hex');}
export async function registerDocument(args:{tenantId:string;employeeId?:string;name:string;mimeType:string;storageKey:string;checksum?:string}){
  const r=await query<{id:string}>(`INSERT INTO documents(tenant_id,employee_id,name,mime_type,storage_key,checksum) VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,[args.tenantId,args.employeeId??null,args.name,args.mimeType,args.storageKey,args.checksum??null]);
  return r.rows[0].id;
}
export async function listEmployeeDocuments(args:{tenantId:string;employeeId:string}){
  const r=await query(`SELECT id,name,mime_type,storage_key,checksum,created_at FROM documents WHERE tenant_id=$1 AND employee_id=$2 ORDER BY created_at DESC`,[args.tenantId,args.employeeId]);
  return r.rows;
}
