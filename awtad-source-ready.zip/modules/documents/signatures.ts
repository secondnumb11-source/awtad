import { query } from '../../lib/db';

export async function requestSignature(args:{tenantId:string;documentId:string;signerUserId?:string;signerEmployeeId?:string}){
 const r=await query<{id:string}>(`INSERT INTO document_signatures(tenant_id,document_id,signer_user_id,signer_employee_id) VALUES($1,$2,$3,$4) RETURNING id`,[args.tenantId,args.documentId,args.signerUserId??null,args.signerEmployeeId??null]);
 return r.rows[0];
}
export async function decideSignature(args:{tenantId:string;signatureId:string;status:'signed'|'declined';providerReference?:string}){
 const r=await query(`UPDATE document_signatures SET status=$3,signed_at=CASE WHEN $3='signed' THEN now() ELSE NULL END,provider_reference=COALESCE($4,provider_reference) WHERE tenant_id=$1 AND id=$2 AND status='pending' RETURNING id,status,signed_at`,[args.tenantId,args.signatureId,args.status,args.providerReference??null]);
 if(!r.rowCount) throw new Error('Signature request is not pending or does not belong to tenant');
 return r.rows[0];
}
