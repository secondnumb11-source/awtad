export type StatutoryRule={code:string;employeeRate?:number;employerRate?:number;cap?:number;floor?:number;includedComponents?:string[]};
export function calculateStatutory(base:number,rules:StatutoryRule[]){
  const result:Record<string,{employee:number;employer:number;base:number}>={};
  for(const r of rules){let b=base;if(r.floor!==undefined)b=Math.max(b,r.floor);if(r.cap!==undefined)b=Math.min(b,r.cap);result[r.code]={employee:round(b*(r.employeeRate??0)),employer:round(b*(r.employerRate??0)),base:round(b)};}
  return result;
}
export function round(n:number){return Math.round((n+Number.EPSILON)*100)/100;}
