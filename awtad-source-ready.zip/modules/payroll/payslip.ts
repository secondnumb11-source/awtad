export type PayslipInput={employeeId:string;basic:number;allowances:number;overtime:number;deductions:number;employerContributions?:number};
export function buildPayslip(input:PayslipInput){
  const gross=round(input.basic+input.allowances+input.overtime);
  const deductions=round(input.deductions);
  return {employeeId:input.employeeId,gross,deductions,net:round(gross-deductions),employerContributions:round(input.employerContributions??0)};
}
function round(value:number){return Math.round((value+Number.EPSILON)*100)/100;}
