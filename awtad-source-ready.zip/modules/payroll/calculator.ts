export type PayrollInput={basic:number;allowances:number;deductions:number;overtimeHours:number;overtimeRate:number;daysWorked:number;daysInPeriod:number};
export function calculateGross(i:PayrollInput){return round(i.basic+i.allowances+(i.overtimeHours*i.overtimeRate));}
export function calculateNet(i:PayrollInput){return round(calculateGross(i)-i.deductions);}
export function round(n:number){return Math.round((n+Number.EPSILON)*100)/100;}
