import { query } from '../../lib/db';

export type SettlementInput={basicSalary:number;housingAllowance:number;otherAllowances:number;unusedLeaveDays:number;terminationDate:string;hireDate:string;serviceYears?:number};
export function serviceYears(hireDate:string,terminationDate:string){const a=new Date(hireDate),b=new Date(terminationDate);return Math.max(0,(b.getTime()-a.getTime())/(365.2425*86400000));}
export function calculateEndOfServiceBenefit(i:SettlementInput){
  const years=i.serviceYears ?? serviceYears(i.hireDate,i.terminationDate); const half=0.5*i.basicSalary; const full=i.basicSalary;
  let gross=0;
  if(years<=5) gross=half*years; else gross=half*5+full*(years-5);
  const monthlyBase=i.basicSalary+i.housingAllowance+i.otherAllowances; const leaveValue=monthlyBase/30*i.unusedLeaveDays;
  return {serviceYears:Math.round(years*10000)/10000,eosbBeforeAdjustments:Math.round(gross*100)/100,unusedLeaveCompensation:Math.round(leaveValue*100)/100,baseForSettlement:monthlyBase};
}

export async function buildFinalSettlement(args:{tenantId:string;employeeId:string;terminationDate:string;unusedLeaveDays?:number;deductions?:number}){
  const e=await query<{hire_date:string;basic_salary:string;housing_allowance:string;other_allowances:string}>(`SELECT e.hire_date,c.basic_salary,c.housing_allowance,c.other_allowances FROM employees e LEFT JOIN LATERAL (SELECT * FROM employee_compensation c WHERE c.tenant_id=e.tenant_id AND c.employee_id=e.id AND c.effective_from<= $3::date ORDER BY c.effective_from DESC LIMIT 1) c ON true WHERE e.id=$1 AND e.tenant_id=$2`,[args.employeeId,args.tenantId,args.terminationDate]);
  if(!e.rowCount||!e.rows[0].hire_date) throw new Error('Employee compensation or hire date not found');
  const row=e.rows[0]; const settlement=calculateEndOfServiceBenefit({basicSalary:Number(row.basic_salary||0),housingAllowance:Number(row.housing_allowance||0),otherAllowances:Number(row.other_allowances||0),unusedLeaveDays:args.unusedLeaveDays??0,terminationDate:args.terminationDate,hireDate:row.hire_date});
  const total=settlement.eosbBeforeAdjustments+settlement.unusedLeaveCompensation-(args.deductions??0);
  await query(`UPDATE employee_offboarding SET final_settlement=$1,status='calculated' WHERE tenant_id=$2 AND employee_id=$3 AND termination_date=$4`,[{...settlement,deductions:args.deductions??0,total},args.tenantId,args.employeeId,args.terminationDate]);
  return {...settlement,deductions:args.deductions??0,total};
}
