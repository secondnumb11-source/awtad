export type EosbRule={
  firstFiveYearsFactor:number;
  afterFiveYearsFactor:number;
  resignationMultiplier?:number;
};

export function calculateEosb(args:{monthlyBasic:number;serviceYears:number;reason:'termination'|'resignation';rule:EosbRule}){
  if(args.monthlyBasic<0||args.serviceYears<0) throw new Error('Invalid EOSB inputs');
  const halfMonth=args.monthlyBasic/2;
  const first=Math.min(args.serviceYears,5)*halfMonth*args.rule.firstFiveYearsFactor;
  const after=Math.max(0,args.serviceYears-5)*args.monthlyBasic*args.rule.afterFiveYearsFactor;
  const gross=first+after;
  const multiplier=args.reason==='resignation'?(args.rule.resignationMultiplier??1):1;
  return Math.round(gross*multiplier*100)/100;
}
