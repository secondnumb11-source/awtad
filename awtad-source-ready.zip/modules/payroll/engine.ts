import { query } from '../../lib/db';
import { calculateStatutory, round } from './statutory';

export type PayrollContext={periodStartsOn:string;periodEndsOn:string;statutoryRules?:import('./statutory').StatutoryRule[]};
export async function calculateEmployeePayroll(args:{tenantId:string;employeeId:string;context:PayrollContext}){
  const c=await query(`SELECT ec.* FROM employee_compensation ec WHERE ec.tenant_id=$1 AND ec.employee_id=$2 AND ec.effective_from<= $3::date ORDER BY ec.effective_from DESC LIMIT 1`,[args.tenantId,args.employeeId,args.context.periodEndsOn]);
  if(!c.rowCount) throw new Error('No effective compensation found');
  const row=c.rows[0];
  const attendance=await query<{overtime_minutes:string;worked_minutes:string}>(`SELECT COALESCE(SUM(overtime_minutes),0) overtime_minutes,COALESCE(SUM(worked_minutes),0) worked_minutes FROM attendance_daily_records WHERE tenant_id=$1 AND employee_id=$2 AND work_date BETWEEN $3::date AND $4::date`,[args.tenantId,args.employeeId,args.context.periodStartsOn,args.context.periodEndsOn]);
  const basic=Number(row.basic_salary), allowances=Number(row.housing_allowance)+Number(row.transport_allowance)+Number(row.other_allowances);
  const overtimeMinutes=Number(attendance.rows[0]?.overtime_minutes??0);
  const hourlyBase=basic/30/8;
  const overtime=round(hourlyBase*1.5*(overtimeMinutes/60));
  const gross=round(basic+allowances+overtime);
  const statutory=calculateStatutory(gross,args.context.statutoryRules??[]);
  const employeeDeductions=round(Object.values(statutory).reduce((s,v)=>s+v.employee,0));
  return {employeeId:args.employeeId,basic,allowances,overtime,gross,deductions:employeeDeductions,net:round(gross-employeeDeductions),statutory,overtimeMinutes};
}
