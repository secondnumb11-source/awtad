export type TimeWindow={startMinutes:number;endMinutes:number;crossesMidnight?:boolean;breakMinutes?:number;graceInMinutes?:number;graceOutMinutes?:number};
export function clockMinutes(value:string){const [h,m]=value.split(':').map(Number);if(!Number.isInteger(h)||!Number.isInteger(m)||h<0||h>23||m<0||m>59)throw new Error('Invalid clock time');return h*60+m;}
export function normalizeWindow(window:TimeWindow){const end=window.endMinutes+(window.crossesMidnight?1440:0);return {start:window.startMinutes,end,scheduledMinutes:Math.max(0,end-window.startMinutes-(window.breakMinutes??0))};}
