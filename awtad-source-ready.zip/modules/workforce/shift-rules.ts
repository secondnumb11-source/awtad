export type ShiftRule={start:string;end:string;breakMinutes:number;graceInMinutes:number;graceOutMinutes:number;crossesMidnight:boolean};
export function shiftWindow(date:string,shift:ShiftRule){const start=new Date(`${date}T${shift.start}`);const end=new Date(`${date}T${shift.end}`);if(shift.crossesMidnight || end<=start) end.setDate(end.getDate()+1);return {start,end};}
export function minutesBetween(a:Date,b:Date){return Math.max(0,Math.round((b.getTime()-a.getTime())/60000));}
