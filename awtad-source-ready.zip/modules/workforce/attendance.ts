import { query } from '../../lib/db';
import { isWithinRadius } from './geo';
export type AttendanceInput={tenantId:string;employeeId:string;eventType:'in'|'out';occurredAt:string;source:string;latitude?:number;longitude?:number;locationId?:string};
export async function recordAttendance(input:AttendanceInput){
  if(input.locationId && input.latitude!=null && input.longitude!=null){
    const r=await query<{latitude:number;longitude:number;radius_m:number|null}>(`SELECT latitude,longitude,radius_m FROM locations WHERE id=$1 AND tenant_id=$2 AND is_active=true`,[input.locationId,input.tenantId]);
    const loc=r.rows[0]; if(loc?.radius_m && loc.latitude!=null && loc.longitude!=null && !isWithinRadius(input.latitude,input.longitude,Number(loc.latitude),Number(loc.longitude),loc.radius_m)) throw new Error('Attendance location is outside the allowed radius');
  }
  const r=await query<{id:string}>(`INSERT INTO attendance_events(tenant_id,employee_id,event_type,occurred_at,source,latitude,longitude,metadata) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,[input.tenantId,input.employeeId,input.eventType,input.occurredAt,input.source,input.latitude??null,input.longitude??null,{}]);
  return r.rows[0];
}
