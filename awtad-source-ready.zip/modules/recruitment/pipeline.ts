import { withTransaction, query } from '../../lib/db';
const allowed=['applied','screening','shortlisted','interview','offer','hired','rejected'] as const;
export type ApplicationStage=typeof allowed[number];
export async function moveApplication(args:{tenantId:string;applicationId:string;stage:ApplicationStage;score?:number;metadata?:Record<string,unknown>}){
  if(!allowed.includes(args.stage)) throw new Error('Invalid application stage');
  return withTransaction(async client=>{
    const r=await client.query(`SELECT * FROM applications WHERE id=$1 AND tenant_id=$2 FOR UPDATE`,[args.applicationId,args.tenantId]);
    if(!r.rowCount) throw new Error('Application not found');
    await client.query(`UPDATE applications SET stage=$1,score=COALESCE($2,score),metadata=metadata||$3::jsonb WHERE id=$4 AND tenant_id=$5`,[args.stage,args.score??null,args.metadata??{},args.applicationId,args.tenantId]);
    return {applicationId:args.applicationId,from:r.rows[0].stage,to:args.stage};
  });
}
export async function listPipeline(args:{tenantId:string;vacancyId:string}){
  const r=await query(`SELECT a.id,a.stage,a.score,a.metadata,c.id candidate_id,c.name,c.email,c.phone FROM applications a JOIN candidates c ON c.id=a.candidate_id WHERE a.tenant_id=$1 AND a.vacancy_id=$2 ORDER BY a.id DESC`,[args.tenantId,args.vacancyId]);
  return r.rows;
}
