import { withTransaction, query } from '../../lib/db';
import { evaluateAll, type Condition } from './conditions';

export type WorkflowStep={type:'approval'|'notification'|'action';name:string;assigneeUserId?:string;assigneeEmployeeId?:string;dueHours?:number;payload?:Record<string,unknown>;conditions?:Condition[]};
export type WorkflowDefinition={code:string;steps:WorkflowStep[]};

function nextEligible(steps:WorkflowStep[],start:number,context:Record<string,unknown>){for(let i=start;i<steps.length;i++){if(!steps[i].conditions||evaluateAll(context,steps[i].conditions!))return i;}return -1;}

export async function startWorkflow(args:{tenantId:string;definition:WorkflowDefinition;entityType:string;entityId?:string;context?:Record<string,unknown>}){
  return withTransaction(async client=>{
    const context=args.context??{};
    const i=await client.query<{id:string}>(`INSERT INTO workflow_instances(tenant_id,workflow_code,entity_type,entity_id,status,current_step,context) VALUES($1,$2,$3,$4,'running',0,$5) RETURNING id`,[args.tenantId,args.definition.code,args.entityType,args.entityId??null,context]);
    const stepIndex=nextEligible(args.definition.steps,0,context);
    if(stepIndex<0){await client.query(`UPDATE workflow_instances SET status='completed',completed_at=now() WHERE id=$1`,[i.rows[0].id]);return i.rows[0].id;}
    const first=args.definition.steps[stepIndex];
    await client.query(`UPDATE workflow_instances SET current_step=$2 WHERE id=$1`,[i.rows[0].id,stepIndex]);
    await client.query(`INSERT INTO workflow_tasks(tenant_id,instance_id,step_index,task_type,assignee_user_id,assignee_employee_id,due_at,payload) VALUES($1,$2,$3,$4,$5,$6,CASE WHEN $7::int IS NULL THEN NULL ELSE now()+($7::text||' hours')::interval END,$8)`,[args.tenantId,i.rows[0].id,stepIndex,first.type,first.assigneeUserId??null,first.assigneeEmployeeId??null,first.dueHours??null,first.payload??{}]);
    return i.rows[0].id;
  });
}

export async function completeWorkflowTask(args:{tenantId:string;taskId:string;decision:'approved'|'rejected'|'completed';userId:string;definition:WorkflowDefinition}){
  return withTransaction(async client=>{
    const t=await client.query(`SELECT wt.*,wi.current_step,wi.status AS instance_status,wi.context FROM workflow_tasks wt JOIN workflow_instances wi ON wi.id=wt.instance_id WHERE wt.id=$1 AND wt.tenant_id=$2 FOR UPDATE`,[args.taskId,args.tenantId]);
    if(!t.rowCount) throw new Error('Workflow task not found'); if(t.rows[0].status!=='pending') throw new Error('Workflow task already completed');
    await client.query(`UPDATE workflow_tasks SET status=$1,completed_at=now() WHERE id=$2`,[args.decision==='rejected'?'rejected':'completed',args.taskId]);
    if(args.decision==='rejected'){await client.query(`UPDATE workflow_instances SET status='rejected',completed_at=now() WHERE id=$1`,[t.rows[0].instance_id]);return {status:'rejected'};}
    const next=nextEligible(args.definition.steps,t.rows[0].current_step+1,t.rows[0].context??{});
    if(next<0){await client.query(`UPDATE workflow_instances SET status='completed',completed_at=now() WHERE id=$1`,[t.rows[0].instance_id]);return {status:'completed'};}
    const step=args.definition.steps[next];
    await client.query(`UPDATE workflow_instances SET current_step=$2 WHERE id=$1`,[t.rows[0].instance_id,next]);
    await client.query(`INSERT INTO workflow_tasks(tenant_id,instance_id,step_index,task_type,assignee_user_id,assignee_employee_id,due_at,payload) VALUES($1,$2,$3,$4,$5,$6,CASE WHEN $7::int IS NULL THEN NULL ELSE now()+($7::text||' hours')::interval END,$8)`,[args.tenantId,t.rows[0].instance_id,next,step.type,step.assigneeUserId??null,step.assigneeEmployeeId??null,step.dueHours??null,step.payload??{}]);
    return {status:'running',nextStep:next};
  });
}
export async function escalateOverdueTasks(tenantId:string){return (await query(`UPDATE workflow_tasks SET status='escalated' WHERE tenant_id=$1 AND status='pending' AND due_at IS NOT NULL AND due_at<now() RETURNING id,instance_id`,[tenantId])).rows;}

export async function createRequest(tenantId:string,requesterEmployeeId:string|null,requestType:string,payload:Record<string,unknown>){
 const r=await query<{id:string}>(`INSERT INTO requests(tenant_id,requester_employee_id,request_type,status,payload) VALUES($1,$2,$3,'pending',$4) RETURNING id`,[tenantId,requesterEmployeeId,requestType,payload]);
 return r.rows[0].id;
}

export async function decideRequest(args:{tenantId:string;requestId:string;userId:string;decision:'approved'|'rejected';reason?:string}){
 return withTransaction(async client=>{
  const r=await client.query(`SELECT * FROM requests WHERE id=$1 AND tenant_id=$2 FOR UPDATE`,[args.requestId,args.tenantId]);
  if(!r.rowCount) throw new Error('Request not found');
  if(r.rows[0].status!=='pending') throw new Error('Request is not pending');
  const payload={...(r.rows[0].payload??{}),decisionReason:args.reason??null};
  await client.query(`UPDATE requests SET status=$1,payload=$2,decided_at=now(),decided_by=$3 WHERE id=$4 AND tenant_id=$5`,[args.decision,payload,args.userId,args.requestId,args.tenantId]);
  return {requestId:args.requestId,status:args.decision};
 });
}
