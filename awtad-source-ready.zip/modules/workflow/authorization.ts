export function canCompleteWorkflowTask(args:{taskStatus:string;taskAssigneeUserId?:string|null;taskAssigneeEmployeeId?:string|null;userId:string;userEmployeeId?:string|null}){
  if(args.taskStatus!=='pending') return false;
  if(args.taskAssigneeUserId && args.taskAssigneeUserId===args.userId) return true;
  if(!args.taskAssigneeUserId && args.taskAssigneeEmployeeId && args.taskAssigneeEmployeeId===args.userEmployeeId) return true;
  return !args.taskAssigneeUserId && !args.taskAssigneeEmployeeId;
}
