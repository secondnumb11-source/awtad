export type Condition={field:string;operator:'eq'|'neq'|'gt'|'gte'|'lt'|'lte'|'in'|'exists';value?:unknown};
function getPath(obj:Record<string,unknown>,path:string){return path.split('.').reduce<unknown>((v,k)=>v&&typeof v==='object'?(v as Record<string,unknown>)[k]:undefined,obj);}
export function evaluateCondition(context:Record<string,unknown>,c:Condition){
 const actual=getPath(context,c.field);
 switch(c.operator){case 'exists':return actual!==undefined&&actual!==null;case 'eq':return actual===c.value;case 'neq':return actual!==c.value;case 'gt':return Number(actual)>Number(c.value);case 'gte':return Number(actual)>=Number(c.value);case 'lt':return Number(actual)<Number(c.value);case 'lte':return Number(actual)<=Number(c.value);case 'in':return Array.isArray(c.value)&&c.value.some(v=>v===actual);default:return false;}
}
export function evaluateAll(context:Record<string,unknown>,conditions:Condition[]){return conditions.every(c=>evaluateCondition(context,c));}
