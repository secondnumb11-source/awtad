import { withTransaction, query } from '../../lib/db';
import { canCompleteWorkflowTask } from './authorization';

export type WorkflowDefinition={code:string;steps:Array<{type:'approval'|'notification'|'action';name:string;assigneeUserId?:string;assigneeEmployeeId?:string;dueHours?:number;payload?:Record<string,unknown>}>};
export async function startWorkflow(args:{tenantId:string;definition:WorkflowDefinition;entityType:string;entityId?:string;context?:Record<string,unknown>}){
  return withTransaction(async client=>{
    const i=await client.query<{id:string}>(`INSERT INTO workflow_instances(tenant_id,workflow_code,entity_type,entity_id,status,current_step,context) VALUES($1,$2,$3,$4,'running',0,$5) RETURNING id`,[args.tenantId,args.definition.code,args.entityType,args.entityId??null,args.context??{}]);
    const first=args.definition.steps[0];
    if(first) await client.query(`INSERT INTO workflow_tasks(tenant_id,instance_id,step_index,task_type,assignee_user_id,assignee_employee_id,due_at,payload) VALUES($1,$2,0,$3,$4,$5,CASE WHEN $6::int IS NULL THEN NULL ELSE now()+($6::text||' hours')::interval END,$7)`,[args.tenantId,i.rows[0].id,first.type,first.assigneeUserId??null,first.assigneeEmployeeId??null,first.dueHours??null,first.payload??{}]);
    return i.rows[0].id;
  });
}
export async function completeWorkflowTask(args:{tenantId:string;taskId:string;decision:'approved'|'rejected'|'completed';userId:string;definition:WorkflowDefinition}){
  return withTransaction(async client=>{
    const t=await client.query(`SELECT wt.*,wi.current_step,wi.status AS instance_status FROM workflow_tasks wt JOIN workflow_instances wi ON wi.id=wt.instance_id WHERE wt.id=$1 AND wt.tenant_id=$2 FOR UPDATE`,[args.taskId,args.tenantId]);
    if(!t.rowCount) throw new Error('Workflow task not found');
    const task=t.rows[0];
    const actor=await client.query(`SELECT employee_id FROM users WHERE id=$1 AND tenant_id=$2`,[args.userId,args.tenantId]);
    if(!actor.rowCount) throw new Error('Workflow actor not found');
    if(!canCompleteWorkflowTask({taskStatus:task.status,taskAssigneeUserId:task.assignee_user_id,taskAssigneeEmployeeId:task.assignee_employee_id,userId:args.userId,userEmployeeId:actor.rows[0].employee_id ?? null})) throw new Error('User is not authorized to complete this workflow task');
    await client.query(`UPDATE workflow_tasks SET status=$1,completed_at=now() WHERE id=$2`,[args.decision==='rejected'?'rejected':'completed',args.taskId]);
    if(args.decision==='rejected'){await client.query(`UPDATE workflow_instances SET status='rejected',completed_at=now() WHERE id=$1`,[t.rows[0].instance_id]);return {status:'rejected'};}
    const next=t.rows[0].current_step+1, step=args.definition.steps[next];
    if(!step){await client.query(`UPDATE workflow_instances SET status='completed',completed_at=now(),current_step=$2 WHERE id=$1`,[t.rows[0].instance_id,next]);return {status:'completed'};}
    await client.query(`UPDATE workflow_instances SET current_step=$2 WHERE id=$1`,[t.rows[0].instance_id,next]);
    await client.query(`INSERT INTO workflow_tasks(tenant_id,instance_id,step_index,task_type,assignee_user_id,assignee_employee_id,due_at,payload) VALUES($1,$2,$3,$4,$5,$6,CASE WHEN $7::int IS NULL THEN NULL ELSE now()+($7::text||' hours')::interval END,$8)`,[args.tenantId,t.rows[0].instance_id,next,step.type,step.assigneeUserId??null,step.assigneeEmployeeId??null,step.dueHours??null,step.payload??{}]);
    return {status:'running',nextStep:next};
  });
}

export async function escalateOverdueTasks(tenantId:string){
  const r=await query(`UPDATE workflow_tasks SET status='escalated' WHERE tenant_id=$1 AND status='pending' AND due_at IS NOT NULL AND due_at<now() RETURNING id,instance_id`,[tenantId]);
  return r.rows;
}
