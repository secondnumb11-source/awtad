import { query, withTransaction } from '../../lib/db';
import type { WorkflowDefinition } from './engine';

export async function saveWorkflowDefinition(args:{tenantId:string;code:string;name:string;definition:WorkflowDefinition;activate?:boolean}){
 return withTransaction(async client=>{
  const latest=await client.query<{version:number}>(`SELECT COALESCE(MAX(version),0)::int version FROM workflow_definitions WHERE tenant_id=$1 AND code=$2`,[args.tenantId,args.code]);
  const version=Number(latest.rows[0].version)+1;
  if(args.activate!==false) await client.query(`UPDATE workflow_definitions SET active=false WHERE tenant_id=$1 AND code=$2`,[args.tenantId,args.code]);
  const r=await client.query<{id:string;version:number}>(`INSERT INTO workflow_definitions(tenant_id,code,name,version,active,definition) VALUES($1,$2,$3,$4,$5,$6) RETURNING id,version`,[args.tenantId,args.code,args.name,version,args.activate!==false,args.definition]);
  return r.rows[0];
 });
}
export async function getActiveWorkflowDefinition(tenantId:string,code:string){
 const r=await query<{definition:WorkflowDefinition;version:number}>(`SELECT definition,version FROM workflow_definitions WHERE tenant_id=$1 AND code=$2 AND active=true ORDER BY version DESC LIMIT 1`,[tenantId,code]);
 return r.rows[0]??null;
}
export async function listWorkflowDefinitions(tenantId:string){
 const r=await query(`SELECT id,code,name,version,active,created_at,definition FROM workflow_definitions WHERE tenant_id=$1 ORDER BY code,version DESC`,[tenantId]);
 return r.rows;
}
