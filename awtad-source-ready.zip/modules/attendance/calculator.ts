export type AttendanceShift={start_time:string;end_time:string;break_minutes:number;grace_in_minutes:number;grace_out_minutes:number;crosses_midnight:boolean};
function minutesOf(t:string){const [h,m]=t.split(':').map(Number);return h*60+m;}
export function evaluateAttendance(shift:AttendanceShift,firstIn:Date|null,lastOut:Date|null){
  if(!firstIn||!lastOut) return {workedMinutes:0,lateMinutes:0,earlyLeaveMinutes:0,overtimeMinutes:0,status:'absent' as const};
  const shiftStart=minutesOf(shift.start_time),shiftEnd=minutesOf(shift.end_time)+(shift.crosses_midnight?1440:0);
  const inMin=firstIn.getHours()*60+firstIn.getMinutes();
  const crosses=lastOut.getTime()<firstIn.getTime();
  const outMin=lastOut.getHours()*60+lastOut.getMinutes()+(crosses?1440:0);
  const scheduled=Math.max(0,shiftEnd-shiftStart-shift.break_minutes);
  const worked=Math.max(0,Math.round((lastOut.getTime()-firstIn.getTime())/60000)-shift.break_minutes);
  const effectiveIn=inMin+(shift.crosses_midnight&&inMin<shiftStart?1440:0);
  const late=Math.max(0,effectiveIn-(shiftStart+shift.grace_in_minutes));
  const early=Math.max(0,(shiftEnd-shift.grace_out_minutes)-outMin);
  const overtime=Math.max(0,worked-scheduled);
  return {workedMinutes:worked,lateMinutes:late,earlyLeaveMinutes:early,overtimeMinutes:overtime,status:late||early?'exception':'present' as const};
}
