import { query } from '../../lib/db';
import { evaluateAttendance, type AttendanceShift } from './calculator';
export { evaluateAttendance } from './calculator';
export async function processAttendanceDay(args:{tenantId:string;employeeId:string;workDate:string}) {
  const shift=await query<AttendanceShift & {id:string}>(`SELECT s.* FROM shift_assignments sa JOIN shifts s ON s.id=sa.shift_id WHERE sa.tenant_id=$1 AND sa.employee_id=$2 AND sa.starts_on<= $3::date AND (sa.ends_on IS NULL OR sa.ends_on >= $3::date) ORDER BY sa.starts_on DESC LIMIT 1`,[args.tenantId,args.employeeId,args.workDate]);
  if(!shift.rowCount) throw new Error('No shift assignment for work date');
  const events=await query<{event_type:'in'|'out';occurred_at:string}>(`SELECT event_type,occurred_at FROM attendance_events WHERE tenant_id=$1 AND employee_id=$2 AND occurred_at >= $3::date AND occurred_at < ($3::date + interval '1 day') ORDER BY occurred_at`,[args.tenantId,args.employeeId,args.workDate]);
  const firstIn=events.rows.find((e: {event_type:'in'|'out';occurred_at:string})=>e.event_type==='in')?.occurred_at ?? null; const outs=events.rows.filter((e: {event_type:'in'|'out';occurred_at:string})=>e.event_type==='out'); const lastOut=outs.at(-1)?.occurred_at ?? null;
  const result=evaluateAttendance(shift.rows[0],firstIn?new Date(firstIn):null,lastOut?new Date(lastOut):null);
  await query(`INSERT INTO attendance_daily_records(tenant_id,employee_id,work_date,shift_id,first_in,last_out,worked_minutes,late_minutes,early_leave_minutes,overtime_minutes,status,details) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT(tenant_id,employee_id,work_date) DO UPDATE SET shift_id=EXCLUDED.shift_id,first_in=EXCLUDED.first_in,last_out=EXCLUDED.last_out,worked_minutes=EXCLUDED.worked_minutes,late_minutes=EXCLUDED.late_minutes,early_leave_minutes=EXCLUDED.early_leave_minutes,overtime_minutes=EXCLUDED.overtime_minutes,status=EXCLUDED.status,details=EXCLUDED.details`,[args.tenantId,args.employeeId,args.workDate,shift.rows[0].id,firstIn,lastOut,result.workedMinutes,result.lateMinutes,result.earlyLeaveMinutes,result.overtimeMinutes,result.status,result]);
  return result;
}
