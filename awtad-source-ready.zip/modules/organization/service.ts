import { withTransaction, query } from '../../lib/db';

export async function createOrganization(args:{tenantId:string;name:string;nameAr?:string;parentId?:string;type?:string}) {
  if (args.parentId) {
    const p=await query(`SELECT id FROM organizations WHERE id=$1 AND tenant_id=$2`,[args.parentId,args.tenantId]);
    if(!p.rowCount) throw new Error('Parent organization not found');
  }
  const r=await query<{id:string}>(`INSERT INTO organizations(tenant_id,name,name_ar,parent_id,organization_type) VALUES($1,$2,$3,$4,$5) RETURNING id`,[args.tenantId,args.name,args.nameAr??null,args.parentId??null,args.type??'department']);
  return r.rows[0].id;
}

export async function moveOrganization(args:{tenantId:string;organizationId:string;parentId?:string}) {
  return withTransaction(async client=>{
    const org=await client.query(`SELECT id,parent_id FROM organizations WHERE id=$1 AND tenant_id=$2 FOR UPDATE`,[args.organizationId,args.tenantId]);
    if(!org.rowCount) throw new Error('Organization not found');
    if(args.parentId===args.organizationId) throw new Error('Organization cannot be its own parent');
    if(args.parentId){
      const p=await client.query(`SELECT id FROM organizations WHERE id=$1 AND tenant_id=$2`,[args.parentId,args.tenantId]);
      if(!p.rowCount) throw new Error('Parent organization not found');
      const cycle=await client.query(`WITH RECURSIVE tree AS (SELECT id,parent_id FROM organizations WHERE id=$1 AND tenant_id=$2 UNION ALL SELECT o.id,o.parent_id FROM organizations o JOIN tree t ON o.id=t.parent_id WHERE o.tenant_id=$2) SELECT 1 FROM tree WHERE id=$3 LIMIT 1`,[args.parentId,args.tenantId,args.organizationId]);
      if(cycle.rowCount) throw new Error('Organization hierarchy cycle detected');
    }
    await client.query(`UPDATE organizations SET parent_id=$1 WHERE id=$2 AND tenant_id=$3`,[args.parentId??null,args.organizationId,args.tenantId]);
    return {organizationId:args.organizationId,parentId:args.parentId??null};
  });
}

export async function listOrganizationTree(tenantId:string){
  const r=await query(`SELECT id,name,name_ar,parent_id,organization_type FROM organizations WHERE tenant_id=$1 ORDER BY name`,[tenantId]);
  return r.rows;
}
