import { query } from '../../lib/db';
export async function assignEmployee(args:{tenantId:string;employeeId:string;organizationId?:string;managerId?:string;jobTitle?:string;employmentType?:string;workLocationId?:string;effectiveFrom:string;effectiveTo?:string;reason?:string}){
  const r=await query<{id:string}>(`INSERT INTO employee_assignments(tenant_id,employee_id,organization_id,manager_id,job_title,employment_type,work_location_id,effective_from,effective_to,reason) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,[args.tenantId,args.employeeId,args.organizationId??null,args.managerId??null,args.jobTitle??null,args.employmentType??null,args.workLocationId??null,args.effectiveFrom,args.effectiveTo??null,args.reason??null]);
  return r.rows[0].id;
}
export async function getEffectiveAssignment(args:{tenantId:string;employeeId:string;asOf:string}){
  const r=await query(`SELECT * FROM employee_assignments WHERE tenant_id=$1 AND employee_id=$2 AND effective_from<= $3::date AND (effective_to IS NULL OR effective_to>=$3::date) ORDER BY effective_from DESC LIMIT 1`,[args.tenantId,args.employeeId,args.asOf]);
  return r.rows[0]??null;
}
