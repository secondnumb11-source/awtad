import { query } from '../../lib/db';
export async function writeAudit(args:{tenantId:string;actorUserId?:string;action:string;entityType:string;entityId?:string;before?:unknown;after?:unknown;ip?:string}){
  await query(`INSERT INTO audit_logs(tenant_id,actor_user_id,action,entity_type,entity_id,before_state,after_state,ip_address) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,[args.tenantId,args.actorUserId??null,args.action,args.entityType,args.entityId??null,args.before??null,args.after??null,args.ip??null]);
}
export async function listAudit(args:{tenantId:string;entityType?:string;entityId?:string;limit?:number}){
  const r=await query(`SELECT id,actor_user_id,action,entity_type,entity_id,before_state,after_state,ip_address,created_at FROM audit_logs WHERE tenant_id=$1 AND ($2::text IS NULL OR entity_type=$2) AND ($3::uuid IS NULL OR entity_id=$3) ORDER BY created_at DESC LIMIT $4`,[args.tenantId,args.entityType??null,args.entityId??null,Math.min(Math.max(args.limit??100,1),500)]);
  return r.rows;
}
