import { query } from '../../lib/db';
export async function recordSecurityEvent(args:{tenantId?:string;userId?:string;eventType:string;severity?:'info'|'warning'|'critical';ipAddress?:string;userAgent?:string;metadata?:Record<string,unknown>}){
 const r=await query<{id:string}>(`INSERT INTO security_events(tenant_id,user_id,event_type,severity,ip_address,user_agent,metadata) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,[args.tenantId??null,args.userId??null,args.eventType,args.severity??'info',args.ipAddress??null,args.userAgent??null,args.metadata??{}]);
 return r.rows[0];
}
