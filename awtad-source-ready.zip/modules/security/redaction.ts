const SENSITIVE=/(password|secret|token|api[_-]?key|authorization|cookie|private[_-]?key)/i;
export function redactObject(value:unknown):unknown{
  if(Array.isArray(value)) return value.map(redactObject);
  if(value&&typeof value==='object'){
    return Object.fromEntries(Object.entries(value as Record<string,unknown>).map(([key,val])=>[key,SENSITIVE.test(key)?'[REDACTED]':redactObject(val)]));
  }
  return value;
}
