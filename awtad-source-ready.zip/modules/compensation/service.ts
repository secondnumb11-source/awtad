import { query } from '../../lib/db';

export type CompensationInput={basic:number;housing:number;transport:number;other:number};
export async function setCompensation(args:{tenantId:string;employeeId:string;effectiveFrom:string;input:CompensationInput}){
  const e=await query(`SELECT id FROM employees WHERE id=$1 AND tenant_id=$2`,[args.employeeId,args.tenantId]);
  if(!e.rowCount) throw new Error('Employee not found');
  if(Object.values(args.input).some(v=>!Number.isFinite(v)||v<0)) throw new Error('Compensation values must be non-negative numbers');
  const r=await query<{id:string}>(`INSERT INTO employee_compensation(tenant_id,employee_id,effective_from,basic_salary,housing_allowance,transport_allowance,other_allowances) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(tenant_id,employee_id,effective_from) DO UPDATE SET basic_salary=EXCLUDED.basic_salary,housing_allowance=EXCLUDED.housing_allowance,transport_allowance=EXCLUDED.transport_allowance,other_allowances=EXCLUDED.other_allowances RETURNING id`,[args.tenantId,args.employeeId,args.effectiveFrom,args.input.basic,args.input.housing,args.input.transport,args.input.other]);
  return r.rows[0].id;
}

export async function getEffectiveCompensation(args:{tenantId:string;employeeId:string;asOf:string}){
  const r=await query(`SELECT * FROM employee_compensation WHERE tenant_id=$1 AND employee_id=$2 AND effective_from<= $3::date ORDER BY effective_from DESC LIMIT 1`,[args.tenantId,args.employeeId,args.asOf]);
  return r.rows[0]??null;
}
