import { withTransaction, query } from '../../lib/db';

export type LifecycleEvent = 'offer_accepted'|'contract_signed'|'pre_onboarding_started'|'onboarding_completed'|'probation_started'|'probation_completed'|'transfer'|'promotion'|'termination_started'|'terminated'|'rehired';

export async function recordLifecycleEvent(args:{tenantId:string;employeeId:string;eventType:LifecycleEvent;effectiveOn:string;payload?:Record<string,unknown>;userId?:string}) {
  return withTransaction(async client => {
    const employee = await client.query(`SELECT id, employment_status FROM employees WHERE id=$1 AND tenant_id=$2 FOR UPDATE`,[args.employeeId,args.tenantId]);
    if (!employee.rowCount) throw new Error('Employee not found');
    await client.query(`INSERT INTO employee_lifecycle_events(tenant_id,employee_id,event_type,effective_on,payload,created_by) VALUES($1,$2,$3,$4,$5,$6)`,[args.tenantId,args.employeeId,args.eventType,args.effectiveOn,args.payload ?? {},args.userId ?? null]);
    const status = ({offer_accepted:'pre_onboarding',contract_signed:'pre_onboarding',pre_onboarding_started:'pre_onboarding',onboarding_completed:'active',probation_started:'probation',probation_completed:'active',termination_started:'termination_pending',terminated:'terminated',rehired:'active',transfer:'active',promotion:'active'} as Record<string,string>)[args.eventType];
    if (status) await client.query(`UPDATE employees SET employment_status=$1 WHERE id=$2 AND tenant_id=$3`,[status,args.employeeId,args.tenantId]);
    return {employeeId:args.employeeId,eventType:args.eventType,status};
  });
}

export async function startOnboarding(args:{tenantId:string;employeeId:string;dueOn?:string;checklist?:unknown[]}) {
  const r=await query<{id:string}>(`INSERT INTO employee_onboarding(tenant_id,employee_id,due_on,checklist) VALUES($1,$2,$3,$4) ON CONFLICT(tenant_id,employee_id) DO UPDATE SET due_on=EXCLUDED.due_on, checklist=EXCLUDED.checklist, status='pending' RETURNING id`,[args.tenantId,args.employeeId,args.dueOn ?? null,args.checklist ?? []]);
  await recordLifecycleEvent({tenantId:args.tenantId,employeeId:args.employeeId,eventType:'pre_onboarding_started',effectiveOn:new Date().toISOString().slice(0,10),payload:{onboardingId:r.rows[0].id}});
  return r.rows[0].id;
}

export async function terminateEmployee(args:{tenantId:string;employeeId:string;terminationDate:string;reasonCode?:string;notes?:string;userId?:string}) {
  return withTransaction(async client=>{
    const r=await client.query(`INSERT INTO employee_offboarding(tenant_id,employee_id,termination_date,reason_code,notes) VALUES($1,$2,$3,$4,$5) RETURNING id`,[args.tenantId,args.employeeId,args.terminationDate,args.reasonCode ?? null,args.notes ?? null]);
    await client.query(`UPDATE employees SET employment_status='termination_pending' WHERE id=$1 AND tenant_id=$2`,[args.employeeId,args.tenantId]);
    await client.query(`INSERT INTO employee_lifecycle_events(tenant_id,employee_id,event_type,effective_on,payload,created_by) VALUES($1,$2,'termination_started',$3,$4,$5)`,[args.tenantId,args.employeeId,args.terminationDate,{offboardingId:r.rows[0].id,reasonCode:args.reasonCode ?? null},args.userId ?? null]);
    return r.rows[0].id as string;
  });
}
