import { query } from '../../lib/db';
export type NotificationPreference={inApp:boolean;email:boolean;push:boolean};
export async function getPreference(args:{tenantId:string;userId:string;type:string}):Promise<NotificationPreference>{
 const r=await query<{in_app:boolean;email:boolean;push:boolean}>(`SELECT in_app,email,push FROM notification_preferences WHERE tenant_id=$1 AND user_id=$2 AND notification_type=$3`,[args.tenantId,args.userId,args.type]);
 const row=r.rows[0]; return row?{inApp:row.in_app,email:row.email,push:row.push}:{inApp:true,email:false,push:false};
}
export async function upsertPreference(args:{tenantId:string;userId:string;type:string;preference:NotificationPreference}){
 await query(`INSERT INTO notification_preferences(tenant_id,user_id,notification_type,in_app,email,push) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(tenant_id,user_id,notification_type) DO UPDATE SET in_app=EXCLUDED.in_app,email=EXCLUDED.email,push=EXCLUDED.push`,[args.tenantId,args.userId,args.type,args.preference.inApp,args.preference.email,args.preference.push]);
}
