export type OCRResult={text:string;fields:Record<string,string|number|null>;confidence:number;raw?:unknown};
export interface OCRAdapter { readonly provider:string; extract(document:Buffer,mimeType:string):Promise<OCRResult>; }
export class UnconfiguredOCRAdapter implements OCRAdapter {
 constructor(public readonly provider='unconfigured'){}
 async extract(_document:Buffer,_mimeType:string):Promise<OCRResult>{throw new Error('OCR provider is not configured');}
}
