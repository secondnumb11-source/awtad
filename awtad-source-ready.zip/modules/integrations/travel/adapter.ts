export type TravelSearch={origin:string;destination:string;departure:string;returnDate?:string;passengers:number};
export interface TravelBookingAdapter { readonly provider:string; search(input:TravelSearch):Promise<unknown[]>; book(optionId:string,request:Record<string,unknown>):Promise<{reference:string;status:string}>; cancel(reference:string):Promise<{status:string}>; }
export class UnconfiguredTravelAdapter implements TravelBookingAdapter {
 constructor(public readonly provider='unconfigured'){}
 async search(_input:TravelSearch):Promise<unknown[]>{throw new Error('Travel provider is not configured');}
 async book(_optionId:string,_request:Record<string,unknown>):Promise<{reference:string;status:string}>{throw new Error('Travel provider is not configured');}
 async cancel(_reference:string):Promise<{status:string}>{throw new Error('Travel provider is not configured');}
}
