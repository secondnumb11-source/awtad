export type StatutoryEmployee={employeeId:string;employeeNumber:string;nationalId?:string;employmentStatus:string;basicSalary:number;allowances:number};
export type StatutorySubmission={reference?:string;status:'prepared'|'submitted'|'accepted'|'rejected';raw?:unknown};
export interface StatutoryAdapter { readonly provider:string; validate(input:StatutoryEmployee):Promise<{valid:boolean;errors:string[]}>; prepare(input:StatutoryEmployee):Promise<StatutorySubmission>; submit(input:StatutorySubmission):Promise<StatutorySubmission>; status(reference:string):Promise<StatutorySubmission>; }
export class UnconfiguredStatutoryAdapter implements StatutoryAdapter {
 constructor(public readonly provider:string){}
 async validate(_input:StatutoryEmployee):Promise<{valid:boolean;errors:string[]}>{return {valid:false,errors:[`No verified ${this.provider} connector is configured`]};}
 async prepare(_input:StatutoryEmployee):Promise<StatutorySubmission>{throw new Error(`Statutory provider ${this.provider} is not configured`);}
 async submit(_input:StatutorySubmission):Promise<StatutorySubmission>{throw new Error(`Statutory provider ${this.provider} is not configured`);}
 async status(_reference:string):Promise<StatutorySubmission>{throw new Error(`Statutory provider ${this.provider} is not configured`);}
}
