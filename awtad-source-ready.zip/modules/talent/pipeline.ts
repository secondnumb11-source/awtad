import { query, withTransaction } from '../../lib/db';
export async function moveApplication(args:{tenantId:string;applicationId:string;status:string;userId?:string}){
 return withTransaction(async client=>{
  const r=await client.query(`SELECT * FROM applications WHERE id=$1 AND tenant_id=$2 FOR UPDATE`,[args.applicationId,args.tenantId]); if(!r.rowCount)throw new Error('Application not found');
  await client.query(`UPDATE applications SET status=$1 WHERE id=$2 AND tenant_id=$3`,[args.status,args.applicationId,args.tenantId]);
  await client.query(`INSERT INTO audit_logs(tenant_id,actor_user_id,action,entity_type,entity_id,before_state,after_state) VALUES($1,$2,'application.stage_changed','application',$3,$4,$5)`,[args.tenantId,args.userId??null,args.applicationId,r.rows[0],{...r.rows[0],status:args.status}]);
  return {applicationId:args.applicationId,status:args.status};
 });
}
export async function scheduleInterview(args:{tenantId:string;applicationId:string;interviewerUserId?:string;scheduledAt:string;mode?:string;meetingUrl?:string}){
 const r=await query<{id:string}>(`INSERT INTO recruitment_interviews(tenant_id,application_id,interviewer_user_id,scheduled_at,mode,meeting_url) VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,[args.tenantId,args.applicationId,args.interviewerUserId??null,args.scheduledAt,args.mode??'online',args.meetingUrl??null]); return r.rows[0].id;
}
export async function scoreInterview(args:{tenantId:string;interviewId:string;score:number;feedback:Record<string,unknown>}){const r=await query(`UPDATE recruitment_interviews SET score=$1,feedback=$2,status='completed' WHERE id=$3 AND tenant_id=$4 RETURNING id`,[args.score,args.feedback,args.interviewId,args.tenantId]);if(!r.rowCount)throw new Error('Interview not found');return r.rows[0];}
