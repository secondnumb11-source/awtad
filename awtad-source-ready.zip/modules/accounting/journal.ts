import { withTransaction, query } from '../../lib/db';

type Line={accountId:string;debit?:number;credit?:number;description?:string;employeeId?:string};
export async function postJournal(args:{tenantId:string;entryNumber:string;entryDate:string;description?:string;sourceType?:string;sourceId?:string;lines:Line[]}){
  const debit=args.lines.reduce((n,l)=>n+(l.debit??0),0), credit=args.lines.reduce((n,l)=>n+(l.credit??0),0);
  if(Math.abs(debit-credit)>0.005) throw new Error('Journal entry is not balanced');
  if(!args.lines.length) throw new Error('Journal entry requires lines');
  return withTransaction(async client=>{
    const e=await client.query<{id:string}>(`INSERT INTO journal_entries(tenant_id,entry_number,entry_date,source_type,source_id,status,description) VALUES($1,$2,$3,$4,$5,'posted',$6) RETURNING id`,[args.tenantId,args.entryNumber,args.entryDate,args.sourceType??null,args.sourceId??null,args.description??null]);
    for(const l of args.lines){if((l.debit??0)<0||(l.credit??0)<0||(l.debit??0)>0&&(l.credit??0)>0) throw new Error('Invalid journal line'); await client.query(`INSERT INTO journal_lines(tenant_id,journal_entry_id,account_id,debit,credit,description,employee_id) VALUES($1,$2,$3,$4,$5,$6,$7)`,[args.tenantId,e.rows[0].id,l.accountId,l.debit??0,l.credit??0,l.description??null,l.employeeId??null]);}
    await client.query(`UPDATE journal_entries SET posted_at=now() WHERE id=$1`,[e.rows[0].id]);
    return {id:e.rows[0].id,totalDebit:debit,totalCredit:credit};
  });
}

export async function createExpenseJournal(args:{tenantId:string;entryNumber:string;entryDate:string;expenseAccountId:string;cashOrPayableAccountId:string;amount:number;employeeId?:string;description?:string}){
  return postJournal({tenantId:args.tenantId,entryNumber:args.entryNumber,entryDate:args.entryDate,sourceType:'expense',description:args.description,lines:[{accountId:args.expenseAccountId,debit:args.amount,employeeId:args.employeeId},{accountId:args.cashOrPayableAccountId,credit:args.amount,employeeId:args.employeeId}]});
}

export async function trialBalance(tenantId:string){
  const r=await query(`SELECT a.code,a.name,a.account_type,COALESCE(SUM(jl.debit),0)::numeric debit,COALESCE(SUM(jl.credit),0)::numeric credit,COALESCE(SUM(jl.debit-jl.credit),0)::numeric balance FROM accounting_accounts a LEFT JOIN journal_lines jl ON jl.account_id=a.id AND jl.tenant_id=a.tenant_id WHERE a.tenant_id=$1 GROUP BY a.id ORDER BY a.code`,[tenantId]);
  return r.rows;
}
