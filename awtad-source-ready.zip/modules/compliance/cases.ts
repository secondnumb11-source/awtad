import { query } from '../../lib/db';
export async function openComplianceCase(args:{tenantId:string;employeeId?:string;ruleCode:string;severity?:'low'|'medium'|'high'|'critical';dueOn?:string;evidence?:Record<string,unknown>}){
  const r=await query<{id:string}>(`INSERT INTO compliance_cases(tenant_id,employee_id,rule_code,severity,due_on,evidence) VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,[args.tenantId,args.employeeId??null,args.ruleCode,args.severity??'medium',args.dueOn??null,args.evidence??{}]); return r.rows[0].id;
}
export async function resolveComplianceCase(args:{tenantId:string;caseId:string;userId:string}){const r=await query(`UPDATE compliance_cases SET status='resolved',resolved_at=now(),resolved_by=$1 WHERE id=$2 AND tenant_id=$3 AND status='open' RETURNING id`,[args.userId,args.caseId,args.tenantId]);if(!r.rowCount)throw new Error('Compliance case not found or already resolved');return r.rows[0];}
