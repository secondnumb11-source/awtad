export type LeavePolicy={
  annualEntitlement:number;
  carryoverLimit:number;
  minimumUnit:number;
  maximumConsecutiveDays?:number;
  allowNegativeBalance?:boolean;
};

export function calculateCarryover(remaining:number, policy:LeavePolicy){
  if(!Number.isFinite(remaining)||remaining<0) return 0;
  return Math.min(remaining, Math.max(0,policy.carryoverLimit));
}

export function validateLeaveDuration(days:number, policy:LeavePolicy){
  if(!Number.isFinite(days)||days<=0) throw new Error('Leave duration must be positive');
  if(policy.maximumConsecutiveDays!==undefined && days>policy.maximumConsecutiveDays) throw new Error('Leave exceeds maximum consecutive days');
  const units=Math.round(days/policy.minimumUnit);
  if(Math.abs(units*policy.minimumUnit-days)>1e-9) throw new Error('Leave duration does not match the configured minimum unit');
  return true;
}

export function canApproveLeave(args:{requested:number;available:number;policy:LeavePolicy}){
  validateLeaveDuration(args.requested,args.policy);
  return args.policy.allowNegativeBalance===true || args.requested<=args.available;
}
