import { withTransaction, query } from '../../lib/db';
import { canApproveLeave } from './policy';

export async function ensureAnnualBalance(args:{tenantId:string;employeeId:string;leaveTypeId:string;year:number}) {
  const r=await query<{id:string}>(`INSERT INTO leave_balances(tenant_id,employee_id,leave_type_id,period_year,entitled) SELECT $1,$2,$3,$4,annual_entitlement FROM leave_types WHERE id=$3 AND tenant_id=$1 ON CONFLICT(tenant_id,employee_id,leave_type_id,period_year) DO NOTHING RETURNING id`,[args.tenantId,args.employeeId,args.leaveTypeId,args.year]);
  if (r.rowCount) await query(`INSERT INTO leave_transactions(tenant_id,employee_id,leave_type_id,transaction_date,quantity,transaction_type,notes) VALUES($1,$2,$3,make_date($4,1,1),(SELECT entitled FROM leave_balances WHERE id=$5),'accrual','Initial annual entitlement')`,[args.tenantId,args.employeeId,args.leaveTypeId,args.year,r.rows[0].id]);
}

export async function getAvailableBalance(args:{tenantId:string;employeeId:string;leaveTypeId:string;year:number}) {
  await ensureAnnualBalance(args);
  const r=await query<{entitled:string;used:string;adjusted:string}>(`SELECT entitled,used,(SELECT COALESCE(SUM(CASE WHEN transaction_type IN ('adjustment','carryover','accrual') THEN quantity WHEN transaction_type='reversal' THEN -quantity ELSE 0 END),0) FROM leave_transactions lt WHERE lt.tenant_id=lb.tenant_id AND lt.employee_id=lb.employee_id AND lt.leave_type_id=lb.leave_type_id AND EXTRACT(YEAR FROM lt.transaction_date)=$4) adjusted FROM leave_balances lb WHERE lb.tenant_id=$1 AND lb.employee_id=$2 AND lb.leave_type_id=$3 AND period_year=$4`,[args.tenantId,args.employeeId,args.leaveTypeId,args.year]);
  const row=r.rows[0]; if(!row) throw new Error('Leave balance not found');
  return Number(row.entitled)+Number(row.adjusted)-Number(row.used);
}

export async function approveLeave(args:{tenantId:string;requestId:string;userId:string}) {
  return withTransaction(async client=>{
    const r=await client.query(`SELECT * FROM requests WHERE id=$1 AND tenant_id=$2 AND request_type='leave.request' FOR UPDATE`,[args.requestId,args.tenantId]);
    if(!r.rowCount) throw new Error('Leave request not found');
    if(r.rows[0].status!=='pending') throw new Error('Leave request is not pending');
    const p=r.rows[0].payload as Record<string,unknown>;
    const starts=new Date(String(p.startsOn)); const ends=new Date(String(p.endsOn));
    if(Number.isNaN(starts.valueOf())||Number.isNaN(ends.valueOf())||ends<starts) throw new Error('Invalid leave dates');
    const days=Math.floor((ends.getTime()-starts.getTime())/86400000)+1;
    const employeeId=String(p.employeeId), leaveTypeId=String(p.leaveTypeId), year=starts.getUTCFullYear();
    const balance=await client.query(`SELECT * FROM leave_balances WHERE tenant_id=$1 AND employee_id=$2 AND leave_type_id=$3 AND period_year=$4 FOR UPDATE`,[args.tenantId,employeeId,leaveTypeId,year]);
    if(!balance.rowCount) throw new Error('Leave balance is not initialized');
    const available=Number(balance.rows[0].entitled)-Number(balance.rows[0].used);
    const type=await client.query(`SELECT annual_entitlement,COALESCE(carryover_limit,0) carryover_limit,COALESCE(minimum_unit,1) minimum_unit,maximum_consecutive_days,COALESCE(allow_negative_balance,false) allow_negative_balance FROM leave_types WHERE id=$1 AND tenant_id=$2`,[leaveTypeId,args.tenantId]);
    if(!type.rowCount) throw new Error('Leave type not found');
    const policy={annualEntitlement:Number(type.rows[0].annual_entitlement),carryoverLimit:Number(type.rows[0].carryover_limit),minimumUnit:Number(type.rows[0].minimum_unit),maximumConsecutiveDays:type.rows[0].maximum_consecutive_days==null?undefined:Number(type.rows[0].maximum_consecutive_days),allowNegativeBalance:Boolean(type.rows[0].allow_negative_balance)};
    if(!canApproveLeave({requested:days,available,policy})) throw new Error(`Insufficient leave balance: ${available}`);
    await client.query(`UPDATE leave_balances SET used=used+$1 WHERE id=$2`,[days,balance.rows[0].id]);
    await client.query(`INSERT INTO leave_transactions(tenant_id,employee_id,leave_type_id,transaction_date,quantity,transaction_type,source_request_id) VALUES($1,$2,$3,$4,$5,'usage',$6)`,[args.tenantId,employeeId,leaveTypeId,String(p.startsOn),days,args.requestId]);
    await client.query(`UPDATE requests SET status='approved',decided_at=now(),decided_by=$1 WHERE id=$2`,[args.userId,args.requestId]);
    return {requestId:args.requestId,days,remaining:available-days};
  });
}
