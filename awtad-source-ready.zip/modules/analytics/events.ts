import { query } from '../../lib/db';
export async function trackEvent(args:{tenantId:string;eventName:string;entityType?:string;entityId?:string;properties?:Record<string,unknown>}){await query(`INSERT INTO analytics_events(tenant_id,event_name,entity_type,entity_id,properties) VALUES($1,$2,$3,$4,$5)`,[args.tenantId,args.eventName,args.entityType??null,args.entityId??null,args.properties??{}]);}
