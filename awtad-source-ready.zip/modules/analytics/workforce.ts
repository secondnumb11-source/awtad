import { query } from '../../lib/db';
export async function workforceSnapshot(tenantId:string,asOf:string){
 const [employees,attendance,leave,openCases]=await Promise.all([
  query(`SELECT employment_status,COUNT(*)::int count FROM employees WHERE tenant_id=$1 GROUP BY employment_status`,[tenantId]),
  query(`SELECT COUNT(*)::int days,COALESCE(SUM(worked_minutes),0)::int worked_minutes,COALESCE(SUM(overtime_minutes),0)::int overtime_minutes FROM attendance_daily_records WHERE tenant_id=$1 AND work_date=$2::date`,[tenantId,asOf]),
  query(`SELECT COUNT(*)::int pending FROM requests WHERE tenant_id=$1 AND request_type='leave.request' AND status='pending'`,[tenantId]),
  query(`SELECT COUNT(*)::int open FROM compliance_cases WHERE tenant_id=$1 AND status='open'`,[tenantId])
 ]);
 return {asOf,employees:employees.rows,attendance:attendance.rows[0],pendingLeave:leave.rows[0]?.pending??0,openComplianceCases:openCases.rows[0]?.open??0};
}
