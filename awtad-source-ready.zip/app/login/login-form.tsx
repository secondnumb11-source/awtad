'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginForm(){
 const [email,setEmail]=useState('admin@awtad.local'); const [password,setPassword]=useState('ChangeMe!123'); const [error,setError]=useState(''); const [loading,setLoading]=useState(false); const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault();setLoading(true);setError('');const r=await fetch('/api/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email,password})});if(r.ok){router.replace('/dashboard');router.refresh()}else{const j=await r.json().catch(()=>({}));setError(j.error||'تعذر تسجيل الدخول')}setLoading(false)}
 return <form onSubmit={submit}>{error&&<div className="error">{error}</div>}<div className="field"><label>البريد الإلكتروني</label><input value={email} onChange={e=>setEmail(e.target.value)} type="email" required /></div><div className="field"><label>كلمة المرور</label><input value={password} onChange={e=>setPassword(e.target.value)} type="password" required /></div><button className="btn" disabled={loading}>{loading?'جارٍ الدخول...':'دخول'}</button></form>
}
