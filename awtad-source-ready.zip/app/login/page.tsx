import { getSession } from '@/lib/session';
import { redirect } from 'next/navigation';
import LoginForm from './login-form';

export default async function LoginPage() {
  if (await getSession()) redirect('/dashboard');
  return <main className="login"><section className="login-card"><div className="brand" style={{color:'#102d50'}}>أوتاد<small>منصة الموارد البشرية المؤسسية</small></div><h1 className="title">تسجيل الدخول</h1><p className="subtitle">الوصول الآمن إلى مساحة عمل منشأتك.</p><LoginForm /></section></main>;
}
