import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = { title: 'أوتاد | منصة إدارة الموارد البشرية', description: 'منصة أوتاد المؤسسية لإدارة الموارد البشرية والعمليات المرتبطة بها' };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
