import Link from 'next/link';
import { requireSession } from '@/lib/auth';
import { query } from '@/lib/db';

export default async function DashboardLayout({children}:{children:React.ReactNode}){
 const session=await requireSession();
 const u=await query<{display_name:string}>('SELECT display_name FROM users WHERE id=$1',[session.userId]);
 return <div className="shell"><aside className="sidebar"><div className="brand">أوتاد<small>Enterprise HCM</small></div><nav className="nav"><Link href="/dashboard">الرئيسية</Link><Link href="/dashboard/employees">الموظفون</Link><Link href="/dashboard/attendance">إدارة الدوام</Link><Link href="/dashboard/requests">الطلبات والمعالجة</Link><Link href="/dashboard/notifications">الإشعارات</Link><Link href="/dashboard/manager-users">منصة المدراء</Link><Link href="/dashboard/payroll">الرواتب</Link><Link href="/dashboard/leave">الإجازات</Link><Link href="/dashboard/recruitment">التوظيف</Link><Link href="/dashboard/performance">الأداء</Link><Link href="/dashboard/finance">المالية</Link><Link href="/dashboard/compliance">الامتثال</Link><Link href="/dashboard/workflows">سير العمل</Link></nav></aside><div className="main"><header className="topbar"><strong>مساحة العمل</strong><span className="user">{u.rows[0]?.display_name ?? session.email}</span></header>{children}</div></div>
}
