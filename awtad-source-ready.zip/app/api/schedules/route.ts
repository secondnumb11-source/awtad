import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession, requirePermission } from '../../../lib/auth';
import { query } from '../../../lib/db';
const schema=z.object({employeeId:z.string().uuid(),shiftId:z.string().uuid(),startsOn:z.string(),endsOn:z.string().nullable().optional(),recurrenceRule:z.string().nullable().optional()});
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'schedule.manage');const b=schema.parse(await req.json());const r=await query(`INSERT INTO shift_assignments(tenant_id,employee_id,shift_id,starts_on,ends_on,recurrence_rule) VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,[s.tenantId,b.employeeId,b.shiftId,b.startsOn,b.endsOn??null,b.recurrenceRule??null]);return NextResponse.json(r.rows[0],{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
