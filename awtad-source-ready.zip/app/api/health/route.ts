import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
export async function GET(){try{await query('SELECT 1');return NextResponse.json({status:'ok',service:'awtad-web',database:'ok'});}catch{return NextResponse.json({status:'degraded',service:'awtad-web',database:'unavailable'},{status:503});}}
