import { NextResponse } from 'next/server';
import { requireSession } from '../../../../lib/auth';
import { trialBalance } from '../../../../modules/accounting/journal';
export async function GET(){try{const s=await requireSession();return NextResponse.json(await trialBalance(s.tenantId));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Failed'},{status:400});}}
