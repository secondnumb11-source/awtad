import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession, requirePermission } from '../../../lib/auth';
import { createEmployee } from '../../../modules/core-hr/service';
const schema=z.object({employeeNumber:z.string().min(1),firstName:z.string().min(1),lastName:z.string().min(1),firstNameAr:z.string().optional(),lastNameAr:z.string().optional(),email:z.string().email().optional(),phone:z.string().optional(),organizationId:z.string().uuid().optional(),managerId:z.string().uuid().optional(),hireDate:z.string().optional()});
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'employee.create');const body=schema.parse(await req.json());return NextResponse.json(await createEmployee({tenantId:s.tenantId,...body}),{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
