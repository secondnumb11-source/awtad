import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requirePermission, requireSession } from '../../../../lib/auth';
import { calculateEmployeePayroll } from '../../../../modules/payroll/engine';
const schema=z.object({employeeId:z.string().uuid(),periodStartsOn:z.string(),periodEndsOn:z.string(),statutoryRules:z.array(z.object({code:z.string(),employeeRate:z.number().optional(),employerRate:z.number().optional(),cap:z.number().optional(),floor:z.number().optional(),includedComponents:z.array(z.string()).optional()})).optional()});
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'payroll.read');const b=schema.parse(await req.json());return NextResponse.json(await calculateEmployeePayroll({tenantId:s.tenantId,employeeId:b.employeeId,context:{periodStartsOn:b.periodStartsOn,periodEndsOn:b.periodEndsOn,statutoryRules:b.statutoryRules}}));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
