import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession, requirePermission } from '../../../lib/auth';
import { query } from '../../../lib/db';
import { runPayroll } from '../../../modules/payroll/service';
const schema=z.object({periodId:z.string().uuid()});
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'payroll.run');const b=schema.parse(await req.json());const r=await query<{id:string}>(`INSERT INTO payroll_runs(tenant_id,payroll_period_id,status,started_at) VALUES($1,$2,'calculating',now()) RETURNING id`,[s.tenantId,b.periodId]);const result=await runPayroll(s.tenantId,r.rows[0].id);return NextResponse.json({payrollRunId:r.rows[0].id,...result});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
