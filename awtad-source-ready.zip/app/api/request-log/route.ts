import { NextResponse } from 'next/server';
import { requireSession } from '@/lib/auth';
import { query } from '@/lib/db';

export async function GET() {
  try {
    const s = await requireSession();
    const r = await query(`SELECT request_id,method,route,status_code,duration_ms,created_at FROM api_request_logs WHERE tenant_id=$1 ORDER BY created_at DESC LIMIT 100`, [s.tenantId]);
    return NextResponse.json(r.rows);
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Invalid request' }, { status: 400 });
  }
}
