import { NextResponse } from 'next/server';
import { requireSession } from '../../../lib/auth';
import { query } from '../../../lib/db';
import { evaluateDocumentExpiry } from '../../../modules/compliance/rules';
export async function GET(){try{const s=await requireSession();const r=await query(`SELECT id,employee_id,document_type,document_number,expires_at,status FROM compliance_documents WHERE tenant_id=$1 ORDER BY expires_at ASC NULLS LAST`,[s.tenantId]);return NextResponse.json(r.rows.map(x=>({...x,check:evaluateDocumentExpiry(x.expires_at)})));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Failed'},{status:400});}}
