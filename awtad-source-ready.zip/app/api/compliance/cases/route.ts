import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { openComplianceCase, resolveComplianceCase } from '../../../../modules/compliance/cases';
const create=z.object({employeeId:z.string().uuid().optional(),ruleCode:z.string().min(1),severity:z.enum(['low','medium','high','critical']).optional(),dueOn:z.string().optional(),evidence:z.record(z.string(),z.unknown()).optional()});
export async function POST(req:Request){try{const s=await requireSession();const b=await req.json();if(b.caseId)return NextResponse.json(await resolveComplianceCase({tenantId:s.tenantId,userId:s.userId,caseId:z.string().uuid().parse(b.caseId)}));return NextResponse.json({caseId:await openComplianceCase({tenantId:s.tenantId,...create.parse(b)})},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
