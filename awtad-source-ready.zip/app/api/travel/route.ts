import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../lib/auth';
import { createRequest } from '../../../modules/workflow/engine';
const schema=z.object({employeeId:z.string().uuid(),destination:z.string().min(1),startsOn:z.string(),endsOn:z.string(),estimatedCost:z.number().min(0)});
export async function POST(req:Request){try{const s=await requireSession();const b=schema.parse(await req.json());const requestId=await createRequest(s.tenantId,b.employeeId,'travel.request',b);return NextResponse.json({requestId},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
