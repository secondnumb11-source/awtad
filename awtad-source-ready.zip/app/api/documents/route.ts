import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requirePermission, requireSession } from '../../../lib/auth';
import { listEmployeeDocuments, registerDocument } from '../../../modules/documents/service';
const schema=z.object({employeeId:z.string().uuid().optional(),name:z.string().min(1),mimeType:z.string().min(1),storageKey:z.string().min(1),checksum:z.string().optional()});
export async function GET(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'employee.read');const id=z.string().uuid().parse(new URL(req.url).searchParams.get('employeeId'));return NextResponse.json(await listEmployeeDocuments({tenantId:s.tenantId,employeeId:id}));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'employee.update');return NextResponse.json({id:await registerDocument({tenantId:s.tenantId,...schema.parse(await req.json())})},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
