import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { requestSignature, decideSignature } from '../../../../modules/documents/signatures';
const requestSchema=z.object({documentId:z.string().uuid(),signerUserId:z.string().uuid().optional(),signerEmployeeId:z.string().uuid().optional()});
const decideSchema=z.object({signatureId:z.string().uuid(),status:z.enum(['signed','declined']),providerReference:z.string().optional()});
export async function POST(req:Request){const s=await requireSession();const body=await req.json();const p=body.signatureId?decideSchema.safeParse(body):requestSchema.safeParse(body);if(!p.success)return NextResponse.json({error:p.error.flatten()},{status:400});if('signatureId' in p.data)return NextResponse.json(await decideSignature({...p.data,tenantId:s.tenantId}));return NextResponse.json(await requestSignature({...p.data,tenantId:s.tenantId}),{status:201});}
