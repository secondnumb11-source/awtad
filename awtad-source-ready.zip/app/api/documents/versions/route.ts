import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { addDocumentVersion, listDocumentVersions } from '../../../../modules/documents/versions';
const schema=z.object({documentId:z.string().uuid(),storageKey:z.string().min(1),checksum:z.string().min(1),mimeType:z.string().min(1)});
export async function GET(req:Request){const s=await requireSession();const id=new URL(req.url).searchParams.get('documentId');if(!id)return NextResponse.json({error:'documentId is required'},{status:400});return NextResponse.json(await listDocumentVersions(s.tenantId,id));}
export async function POST(req:Request){const s=await requireSession();const p=schema.safeParse(await req.json());if(!p.success)return NextResponse.json({error:p.error.flatten()},{status:400});return NextResponse.json(await addDocumentVersion({...p.data,tenantId:s.tenantId,createdBy:s.userId}),{status:201});}
