import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { completeWorkflowTask } from '../../../../modules/workflow/runtime';
const schema=z.object({taskId:z.string().uuid(),decision:z.enum(['approved','rejected','completed']),workflowCode:z.string(),steps:z.array(z.object({type:z.enum(['approval','notification','action']),name:z.string(),assigneeUserId:z.string().uuid().optional(),assigneeEmployeeId:z.string().uuid().optional(),dueHours:z.number().int().positive().optional(),payload:z.record(z.string(),z.unknown()).optional()}))});
export async function POST(req:Request){try{const s=await requireSession();const b=schema.parse(await req.json());return NextResponse.json(await completeWorkflowTask({tenantId:s.tenantId,userId:s.userId,taskId:b.taskId,decision:b.decision,definition:{code:b.workflowCode,steps:b.steps}}));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
