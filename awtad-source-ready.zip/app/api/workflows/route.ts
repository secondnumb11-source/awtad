import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../lib/auth';
import { startWorkflow } from '../../../modules/workflow/runtime';
const step=z.object({type:z.enum(['approval','notification','action']),name:z.string(),assigneeUserId:z.string().uuid().optional(),assigneeEmployeeId:z.string().uuid().optional(),dueHours:z.number().int().positive().optional(),payload:z.record(z.string(),z.unknown()).optional()});
const schema=z.object({workflowCode:z.string().min(1),entityType:z.string().min(1),entityId:z.string().uuid().optional(),context:z.record(z.string(),z.unknown()).optional(),steps:z.array(step).min(1)});
export async function POST(req:Request){try{const s=await requireSession();const b=schema.parse(await req.json());return NextResponse.json({workflowInstanceId:await startWorkflow({tenantId:s.tenantId,definition:{code:b.workflowCode,steps:b.steps},entityType:b.entityType,entityId:b.entityId,context:b.context})},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
