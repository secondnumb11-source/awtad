import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requirePermission, requireSession } from '../../../../lib/auth';
import { listWorkflowDefinitions, saveWorkflowDefinition } from '../../../../modules/workflow/definitions';
const step=z.object({type:z.enum(['approval','notification','action']),name:z.string(),assigneeUserId:z.string().uuid().optional(),assigneeEmployeeId:z.string().uuid().optional(),dueHours:z.number().int().positive().optional(),payload:z.record(z.string(),z.unknown()).optional(),conditions:z.array(z.object({field:z.string(),operator:z.enum(['eq','neq','gt','gte','lt','lte','in','exists']),value:z.unknown().optional()})).optional()});
const schema=z.object({code:z.string().min(1),name:z.string().min(1),activate:z.boolean().optional(),definition:z.object({code:z.string().min(1),steps:z.array(step)})});
export async function GET(){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'workflow.manage');return NextResponse.json(await listWorkflowDefinitions(s.tenantId));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'workflow.manage');const b=schema.parse(await req.json());return NextResponse.json(await saveWorkflowDefinition({tenantId:s.tenantId,...b}),{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
