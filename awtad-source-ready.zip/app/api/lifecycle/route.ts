import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../lib/auth';
import { recordLifecycleEvent, startOnboarding, terminateEmployee } from '../../../modules/lifecycle/service';
const event=z.object({employeeId:z.string().uuid(),eventType:z.enum(['offer_accepted','contract_signed','pre_onboarding_started','onboarding_completed','probation_started','probation_completed','transfer','promotion','termination_started','terminated','rehired']),effectiveOn:z.string(),payload:z.record(z.string(),z.unknown()).optional()});
const onboarding=z.object({employeeId:z.string().uuid(),dueOn:z.string().optional(),checklist:z.array(z.unknown()).optional()});
const termination=z.object({employeeId:z.string().uuid(),terminationDate:z.string(),reasonCode:z.string().optional(),notes:z.string().optional()});
export async function POST(req:Request){try{const s=await requireSession();const b=await req.json();if(b.action==='onboarding') return NextResponse.json({onboardingId:await startOnboarding({tenantId:s.tenantId,...onboarding.parse(b)})},{status:201});if(b.action==='terminate') return NextResponse.json({offboardingId:await terminateEmployee({tenantId:s.tenantId,userId:s.userId,...termination.parse(b)})},{status:201});const e=event.parse(b);return NextResponse.json(await recordLifecycleEvent({tenantId:s.tenantId,userId:s.userId,...e}),{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
