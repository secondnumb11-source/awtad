import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../lib/auth';
import { createRequest } from '../../../modules/workflow/engine';
const schema=z.object({employeeId:z.string().uuid(),leaveTypeId:z.string().uuid(),startsOn:z.string(),endsOn:z.string(),reason:z.string().optional()});
export async function POST(req:Request){try{const s=await requireSession();const b=schema.parse(await req.json());const id=await createRequest(s.tenantId,b.employeeId,'leave.request',b);return NextResponse.json({requestId:id},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
