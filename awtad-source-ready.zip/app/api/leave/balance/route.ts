import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { getAvailableBalance } from '../../../../modules/leave/engine';
const schema=z.object({employeeId:z.string().uuid(),leaveTypeId:z.string().uuid(),year:z.number().int()});
export async function GET(req:Request){try{const s=await requireSession();const u=new URL(req.url);const b=schema.parse({employeeId:u.searchParams.get('employeeId'),leaveTypeId:u.searchParams.get('leaveTypeId'),year:Number(u.searchParams.get('year'))});return NextResponse.json({available:await getAvailableBalance({tenantId:s.tenantId,...b})});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
