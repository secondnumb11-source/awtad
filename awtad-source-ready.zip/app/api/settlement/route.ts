import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../lib/auth';
import { buildFinalSettlement } from '../../../modules/payroll/settlement';
const schema=z.object({employeeId:z.string().uuid(),terminationDate:z.string(),unusedLeaveDays:z.number().nonnegative().default(0),deductions:z.number().nonnegative().default(0)});
export async function POST(req:Request){try{const s=await requireSession();return NextResponse.json(await buildFinalSettlement({tenantId:s.tenantId,...schema.parse(await req.json())}));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
