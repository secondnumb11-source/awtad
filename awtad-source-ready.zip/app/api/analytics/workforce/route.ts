import { NextResponse } from 'next/server';
import { requirePermission, requireSession } from '../../../../lib/auth';
import { workforceSnapshot } from '../../../../modules/analytics/workforce';
export async function GET(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'dashboard.read');const date=new URL(req.url).searchParams.get('asOf')??new Date().toISOString().slice(0,10);return NextResponse.json(await workforceSnapshot(s.tenantId,date));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
