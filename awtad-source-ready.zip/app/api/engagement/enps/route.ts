import { NextResponse } from 'next/server';
import { requireSession } from '../../../../lib/auth';
import { calculateENPS } from '../../../../modules/engagement/surveys';
export async function GET(req:Request){try{const s=await requireSession();const surveyId=new URL(req.url).searchParams.get('surveyId');if(!surveyId)throw new Error('surveyId is required');return NextResponse.json(await calculateENPS(s.tenantId,surveyId));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
