import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requirePermission, requireSession } from '../../../../lib/auth';
import { listPipeline, moveApplication } from '../../../../modules/recruitment/pipeline';
const schema=z.object({applicationId:z.string().uuid(),stage:z.enum(['applied','screening','shortlisted','interview','offer','hired','rejected']),score:z.number().min(0).max(100).optional(),metadata:z.record(z.string(),z.unknown()).optional()});
export async function GET(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'recruitment.manage');const id=z.string().uuid().parse(new URL(req.url).searchParams.get('vacancyId'));return NextResponse.json(await listPipeline({tenantId:s.tenantId,vacancyId:id}));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'recruitment.manage');return NextResponse.json(await moveApplication({tenantId:s.tenantId,...schema.parse(await req.json())}));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
