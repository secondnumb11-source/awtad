import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { scheduleInterview, scoreInterview } from '../../../../modules/talent/pipeline';
const schedule=z.object({applicationId:z.string().uuid(),interviewerUserId:z.string().uuid().optional(),scheduledAt:z.string(),mode:z.string().optional(),meetingUrl:z.string().url().optional()});
const score=z.object({interviewId:z.string().uuid(),score:z.number().min(0).max(100),feedback:z.record(z.string(),z.unknown()).default({})});
export async function POST(req:Request){try{const s=await requireSession();const b=await req.json();if(b.interviewId)return NextResponse.json(await scoreInterview({tenantId:s.tenantId,...score.parse(b)}));return NextResponse.json({interviewId:await scheduleInterview({tenantId:s.tenantId,...schedule.parse(b)})},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
