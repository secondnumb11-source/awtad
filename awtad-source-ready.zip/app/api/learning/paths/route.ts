import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { assignLearningPath, recalculatePathProgress } from '../../../../modules/learning/paths';
const schema=z.object({employeeId:z.string().uuid(),learningPathId:z.string().uuid()});
export async function POST(req:Request){try{const s=await requireSession();const raw=await req.json();const b=schema.parse(raw);if(raw.action==='recalculate')return NextResponse.json(await recalculatePathProgress({tenantId:s.tenantId,...b}));return NextResponse.json({assignmentId:await assignLearningPath({tenantId:s.tenantId,...b})},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
