import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { postApprovedExpense } from '../../../../modules/finance/expense-posting';
const schema=z.object({expenseId:z.string().uuid(),expenseAccountId:z.string().uuid(),payableAccountId:z.string().uuid(),entryNumber:z.string(),entryDate:z.string()});
export async function POST(req:Request){try{const s=await requireSession();return NextResponse.json(await postApprovedExpense({tenantId:s.tenantId,...schema.parse(await req.json())}));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
