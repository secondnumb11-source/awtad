import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession, requirePermission } from '../../../lib/auth';
import { query } from '../../../lib/db';
const schema=z.object({userId:z.string().uuid(),organizationId:z.string().uuid().optional(),employeeId:z.string().uuid().optional()}).refine(x=>x.organizationId||x.employeeId,{message:'A scope target is required'});
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'manager.scope.manage');const b=schema.parse(await req.json());const r=await query(`INSERT INTO manager_scopes(tenant_id,user_id,organization_id,employee_id) VALUES($1,$2,$3,$4) RETURNING *`,[s.tenantId,b.userId,b.organizationId??null,b.employeeId??null]);return NextResponse.json(r.rows[0],{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
