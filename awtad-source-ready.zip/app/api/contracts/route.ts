import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../lib/auth';
import { query } from '../../../lib/db';
const schema=z.object({employeeId:z.string().uuid(),contractNumber:z.string().min(1),contractType:z.string().default('indefinite'),startsOn:z.string(),endsOn:z.string().optional(),probationDays:z.number().int().nonnegative().default(0),status:z.enum(['draft','active','expired','terminated']).default('draft'),salarySnapshot:z.record(z.string(),z.unknown()).default({})});
export async function POST(req:Request){try{const s=await requireSession();const b=schema.parse(await req.json());const r=await query<{id:string}>(`INSERT INTO employment_contracts(tenant_id,employee_id,contract_number,contract_type,starts_on,ends_on,probation_days,status,salary_snapshot) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,[s.tenantId,b.employeeId,b.contractNumber,b.contractType,b.startsOn,b.endsOn??null,b.probationDays,b.status,b.salarySnapshot]);return NextResponse.json({contractId:r.rows[0].id},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
