import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession, requirePermission } from '../../../lib/auth';
import { query } from '../../../lib/db';
const schema=z.object({name:z.string().min(1),startTime:z.string(),endTime:z.string(),breakMinutes:z.number().int().min(0).default(0),graceInMinutes:z.number().int().min(0).default(0),graceOutMinutes:z.number().int().min(0).default(0),crossesMidnight:z.boolean().default(false),locationId:z.string().uuid().nullable().optional()});
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'shift.manage');const b=schema.parse(await req.json());const r=await query(`INSERT INTO shifts(tenant_id,name,start_time,end_time,break_minutes,grace_in_minutes,grace_out_minutes,crosses_midnight,location_id) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,[s.tenantId,b.name,b.startTime,b.endTime,b.breakMinutes,b.graceInMinutes,b.graceOutMinutes,b.crossesMidnight,b.locationId??null]);return NextResponse.json(r.rows[0],{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
