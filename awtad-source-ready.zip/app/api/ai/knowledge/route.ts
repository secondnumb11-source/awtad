import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requirePermission, requireSession } from '../../../../lib/auth';
import { indexKnowledgeDocument, lexicalRetrieve } from '../../../../modules/ai/rag';
const schema=z.object({title:z.string().min(1),sourceType:z.string().min(1),sourceKey:z.string().optional(),content:z.string().min(1),metadata:z.record(z.string(),z.unknown()).optional()});
export async function GET(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'dashboard.read');const q=new URL(req.url).searchParams.get('q')??'';return NextResponse.json(await lexicalRetrieve({tenantId:s.tenantId,queryText:q}));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'integration.manage');return NextResponse.json({id:await indexKnowledgeDocument({tenantId:s.tenantId,...schema.parse(await req.json())})},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
