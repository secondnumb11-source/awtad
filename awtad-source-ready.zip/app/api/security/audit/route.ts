import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requirePermission, requireSession } from '../../../../lib/auth';
import { listAudit } from '../../../../modules/security/audit';
export async function GET(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'audit.read');const u=new URL(req.url);return NextResponse.json(await listAudit({tenantId:s.tenantId,entityType:u.searchParams.get('entityType')??undefined,entityId:u.searchParams.get('entityId')?z.string().uuid().parse(u.searchParams.get('entityId')):undefined,limit:u.searchParams.get('limit')?Number(u.searchParams.get('limit')):100}));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
