import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { recordSecurityEvent } from '../../../../modules/security/events';
const schema=z.object({eventType:z.string().min(1),severity:z.enum(['info','warning','critical']).optional(),metadata:z.record(z.string(),z.unknown()).optional()});
export async function POST(req:Request){const s=await requireSession();const p=schema.safeParse(await req.json());if(!p.success)return NextResponse.json({error:p.error.flatten()},{status:400});return NextResponse.json(await recordSecurityEvent({...p.data,tenantId:s.tenantId,userId:s.userId}),{status:201});}
