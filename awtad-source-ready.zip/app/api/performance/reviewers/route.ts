import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { assignReviewer, submitReviewer } from '../../../../modules/performance/reviews';
const assign=z.object({reviewId:z.string().uuid(),reviewerEmployeeId:z.string().uuid(),relationship:z.string().optional()});
const submit=z.object({reviewerId:z.string().uuid(),scores:z.record(z.string(),z.number()),comments:z.string().optional()});
export async function POST(req:Request){try{const s=await requireSession();const b=await req.json();if(b.reviewerId)return NextResponse.json(await submitReviewer({tenantId:s.tenantId,...submit.parse(b)}));return NextResponse.json({reviewerId:await assignReviewer({tenantId:s.tenantId,...assign.parse(b)})},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
