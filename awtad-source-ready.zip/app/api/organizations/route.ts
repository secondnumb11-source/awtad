import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requirePermission, requireSession } from '../../../lib/auth';
import { createOrganization, listOrganizationTree, moveOrganization } from '../../../modules/organization/service';
const create=z.object({name:z.string().min(1),nameAr:z.string().optional(),parentId:z.string().uuid().optional(),type:z.string().optional()});
const move=z.object({organizationId:z.string().uuid(),parentId:z.string().uuid().nullable().optional()});
export async function GET(){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'organization.read');return NextResponse.json(await listOrganizationTree(s.tenantId));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
export async function POST(req:Request){try{const s=await requireSession();await requirePermission(s.userId,s.tenantId,'organization.manage');const b=await req.json();if(b.action==='move')return NextResponse.json(await moveOrganization({tenantId:s.tenantId,...move.parse(b)}));return NextResponse.json({id:await createOrganization({tenantId:s.tenantId,...create.parse(b)})},{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
