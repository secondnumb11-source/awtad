import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../lib/auth';
import { createRequest, decideRequest } from '../../../modules/workflow/engine';
import { bodyHash, getIdempotentResponse, jsonError, jsonOk, requestId, saveIdempotentResponse } from '../../../lib/api';

const create=z.object({requesterEmployeeId:z.string().uuid().nullable().optional(),requestType:z.string().min(1),payload:z.record(z.string(),z.unknown()).default({})});
const decide=z.object({requestId:z.string().uuid(),decision:z.enum(['approved','rejected']),reason:z.string().optional()});

export async function POST(req:Request){
  const rid=requestId(req); const key=req.headers.get('Idempotency-Key') ?? undefined;
  try{
    const s=await requireSession(); const body=await req.json(); const hash=bodyHash(body);
    const cached=await getIdempotentResponse({tenantId:s.tenantId,userId:s.userId,key,requestHash:hash});
    if(cached) return jsonOk(cached.body,cached.status,rid);
    let result:unknown; let status=200;
    if(body.requestId){const b=decide.parse(body);result=await decideRequest({tenantId:s.tenantId,userId:s.userId,...b});}
    else {const b=create.parse(body);result=await createRequest(s.tenantId,b.requesterEmployeeId??null,b.requestType,b.payload);status=201;}
    await saveIdempotentResponse({tenantId:s.tenantId,userId:s.userId,key,requestHash:hash,status,body:result});
    return jsonOk(result,status,rid);
  }catch(e){return jsonError(e,400,rid);}
}
