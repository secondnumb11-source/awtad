import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { processAttendanceDay } from '../../../../modules/attendance/engine';
const schema=z.object({employeeId:z.string().uuid(),workDate:z.string()});
export async function POST(req:Request){try{const s=await requireSession();return NextResponse.json(await processAttendanceDay({tenantId:s.tenantId,...schema.parse(await req.json())}));}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
