import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../lib/auth';
import { recordAttendance } from '../../../modules/workforce/attendance';
const schema=z.object({employeeId:z.string().uuid(),eventType:z.enum(['in','out']),occurredAt:z.string().datetime(),source:z.string().default('manual'),latitude:z.number().optional(),longitude:z.number().optional(),locationId:z.string().uuid().optional()});
export async function POST(req:Request){try{const s=await requireSession();const b=schema.parse(await req.json());return NextResponse.json(await recordAttendance({tenantId:s.tenantId,...b}),{status:201});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Invalid request'},{status:400});}}
