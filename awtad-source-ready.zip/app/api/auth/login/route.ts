import { NextResponse } from 'next/server';
import { z } from 'zod';
import { query } from '@/lib/db';
import { verifyPassword } from '@/lib/password';
import { setSession } from '@/lib/session';

const schema=z.object({email:z.string().email(),password:z.string().min(1)});
export async function POST(req:Request){
 try{const input=schema.parse(await req.json());const result=await query<{id:string;tenant_id:string;email:string;password_hash:string}>('SELECT id,tenant_id,email,password_hash FROM users WHERE lower(email)=lower($1) AND is_active=true LIMIT 1',[input.email]);const user=result.rows[0];if(!user||!verifyPassword(input.password,user.password_hash))return NextResponse.json({error:'بيانات الدخول غير صحيحة'},{status:401});await setSession({userId:user.id,tenantId:user.tenant_id,email:user.email});return NextResponse.json({ok:true});}catch{return NextResponse.json({error:'طلب غير صالح'},{status:400})}
}
