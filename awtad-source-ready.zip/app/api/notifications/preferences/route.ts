import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSession } from '../../../../lib/auth';
import { getPreference, upsertPreference } from '../../../../modules/notifications/preferences';
const schema=z.object({type:z.string().min(1),inApp:z.boolean(),email:z.boolean(),push:z.boolean()});
export async function GET(req:Request){const s=await requireSession();const type=new URL(req.url).searchParams.get('type');if(!type)return NextResponse.json({error:'type is required'},{status:400});return NextResponse.json(await getPreference({tenantId:s.tenantId,userId:s.userId,type}));}
export async function PUT(req:Request){const s=await requireSession();const p=schema.safeParse(await req.json());if(!p.success)return NextResponse.json({error:p.error.flatten()},{status:400});await upsertPreference({tenantId:s.tenantId,userId:s.userId,type:p.data.type,preference:{inApp:p.data.inApp,email:p.data.email,push:p.data.push}});return NextResponse.json({ok:true});}
