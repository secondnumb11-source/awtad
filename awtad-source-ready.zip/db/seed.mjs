import pg from 'pg';
import crypto from 'node:crypto';
const { Pool } = pg; const pool = new Pool({connectionString:process.env.DATABASE_URL});
const hash=(password)=>{const salt=crypto.randomBytes(16).toString('hex');const derived=crypto.scryptSync(password,salt,64).toString('hex');return `scrypt:${salt}:${derived}`;};
const permissions=[
 ['dashboard.read','View dashboard'],['organization.read','View organization hierarchy'],['organization.manage','Manage organization hierarchy'],['audit.read','View audit log'],['document.read','View employee documents'],['document.manage','Manage employee documents'],['employee.read','View employees'],['employee.create','Create employees'],['employee.update','Update employees'],
 ['attendance.read','View attendance'],['attendance.manage','Manage attendance'],['shift.manage','Manage shifts'],['schedule.manage','Manage schedules'],
 ['request.read','View requests'],['request.decide','Approve or reject requests'],['manager.scope.manage','Manage manager data scopes'],['notification.manage','Manage notifications'],
 ['payroll.read','View payroll'],['payroll.run','Run payroll'],['compliance.read','View compliance'],['integration.manage','Manage integrations'],['workflow.manage','Manage workflows'],
 ['recruitment.manage','Manage recruitment'],['performance.manage','Manage performance'],['learning.manage','Manage learning'],['finance.manage','Manage finance'],['lifecycle.manage','Manage employee lifecycle'],['leave.manage','Manage leave'],['accounting.manage','Manage accounting'],['recruitment.interview','Manage recruitment interviews'],['performance.review','Manage performance reviews'],['learning.path','Manage learning paths'],['engagement.read','View engagement'],['compliance.case','Manage compliance cases']
];
try{await pool.query('BEGIN');
 const t=await pool.query(`INSERT INTO tenants(name,name_ar) VALUES('Awtad Demo','أوتاد التجريبية') RETURNING id`);const tenantId=t.rows[0].id;
 for(const [code,description] of permissions) await pool.query(`INSERT INTO permissions(code,description) VALUES($1,$2) ON CONFLICT(code) DO UPDATE SET description=excluded.description`,[code,description]);
 const role=await pool.query(`INSERT INTO roles(tenant_id,code,name) VALUES($1,'system_admin','System Administrator') RETURNING id`,[tenantId]);
 for(const [code] of permissions) await pool.query(`INSERT INTO role_permissions(role_id,permission_id) VALUES($1,$2) ON CONFLICT DO NOTHING`,[role.rows[0].id,code]);
 const password=process.env.AWTAD_SEED_ADMIN_PASSWORD;if(!password) throw new Error('AWTAD_SEED_ADMIN_PASSWORD is required for seed');
 const user=await pool.query(`INSERT INTO users(tenant_id,email,password_hash,display_name) VALUES($1,'admin@awtad.local',$2,'مدير النظام') RETURNING id`,[tenantId,hash(password)]);await pool.query(`INSERT INTO user_roles(user_id,role_id) VALUES($1,$2)`,[user.rows[0].id,role.rows[0].id]);
 const org=await pool.query(`INSERT INTO organizations(tenant_id,name,name_ar,organization_type) VALUES($1,'Human Resources','الموارد البشرية','department') RETURNING id`,[tenantId]);
 await pool.query(`INSERT INTO employees(tenant_id,employee_number,first_name,last_name,first_name_ar,last_name_ar,email,organization_id,hire_date) VALUES($1,'AWT-0001','System','Administrator','مدير','النظام','admin@awtad.local',$2,CURRENT_DATE)`,[tenantId,org.rows[0].id]);
 await pool.query('COMMIT'); console.log('Seed complete. Admin password supplied through AWTAD_SEED_ADMIN_PASSWORD.');
}catch(e){await pool.query('ROLLBACK');throw e;}finally{await pool.end();}
