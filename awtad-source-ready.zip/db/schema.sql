CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  name_ar TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  locale TEXT NOT NULL DEFAULT 'ar-SA',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, email)
);

CREATE TABLE IF NOT EXISTS roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  UNIQUE (tenant_id, code)
);

CREATE TABLE IF NOT EXISTS permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT PRIMARY KEY,
  description TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id TEXT NOT NULL REFERENCES permissions(code) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS user_roles (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, role_id)
);

CREATE TABLE IF NOT EXISTS organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  name_ar TEXT,
  parent_id UUID REFERENCES organizations(id) ON DELETE SET NULL,
  organization_type TEXT NOT NULL DEFAULT 'department',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS employees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_number TEXT NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  first_name_ar TEXT,
  last_name_ar TEXT,
  email TEXT,
  phone TEXT,
  organization_id UUID REFERENCES organizations(id) ON DELETE SET NULL,
  manager_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  employment_status TEXT NOT NULL DEFAULT 'active',
  hire_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, employee_number)
);

CREATE TABLE IF NOT EXISTS locations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  latitude NUMERIC(10,7),
  longitude NUMERIC(10,7),
  radius_m INTEGER,
  is_active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS shifts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  break_minutes INTEGER NOT NULL DEFAULT 0,
  grace_in_minutes INTEGER NOT NULL DEFAULT 0,
  grace_out_minutes INTEGER NOT NULL DEFAULT 0,
  crosses_midnight BOOLEAN NOT NULL DEFAULT false,
  location_id UUID REFERENCES locations(id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS attendance_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL CHECK (event_type IN ('in','out')),
  occurred_at TIMESTAMPTZ NOT NULL,
  source TEXT NOT NULL DEFAULT 'manual',
  latitude NUMERIC(10,7),
  longitude NUMERIC(10,7),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  requester_employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  request_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at TIMESTAMPTZ,
  decided_by UUID REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  recipient_user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  recipient_employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  notification_type TEXT NOT NULL DEFAULT 'general',
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  actor_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  before_state JSONB,
  after_state JSONB,
  ip_address INET,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_employees_tenant ON employees(tenant_id);
CREATE INDEX IF NOT EXISTS idx_attendance_employee_time ON attendance_events(employee_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_requests_tenant_status ON requests(tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_tenant_time ON audit_logs(tenant_id, created_at DESC);

-- Phase 2+ domain expansion
CREATE TABLE IF NOT EXISTS manager_scopes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (organization_id IS NOT NULL OR employee_id IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS idx_manager_scopes_user ON manager_scopes(tenant_id,user_id);

CREATE TABLE IF NOT EXISTS employee_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  organization_id UUID REFERENCES organizations(id) ON DELETE SET NULL,
  manager_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  job_title TEXT, employment_type TEXT, work_location_id UUID REFERENCES locations(id) ON DELETE SET NULL,
  effective_from DATE NOT NULL, effective_to DATE, reason TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_employee_assignments_employee ON employee_assignments(tenant_id,employee_id,effective_from DESC);

CREATE TABLE IF NOT EXISTS shift_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, shift_id UUID NOT NULL REFERENCES shifts(id) ON DELETE CASCADE,
  starts_on DATE NOT NULL, ends_on DATE, recurrence_rule TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_shift_assignments_employee ON shift_assignments(tenant_id,employee_id,starts_on);

CREATE TABLE IF NOT EXISTS schedule_exceptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, work_date DATE NOT NULL,
  exception_type TEXT NOT NULL, shift_id UUID REFERENCES shifts(id) ON DELETE SET NULL, notes TEXT,
  UNIQUE(tenant_id,employee_id,work_date)
);

CREATE TABLE IF NOT EXISTS leave_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, name TEXT NOT NULL, name_ar TEXT, paid BOOLEAN NOT NULL DEFAULT true,
  annual_entitlement NUMERIC(12,2) NOT NULL DEFAULT 0, requires_attachment BOOLEAN NOT NULL DEFAULT false,
  UNIQUE(tenant_id,code)
);
CREATE TABLE IF NOT EXISTS leave_balances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, leave_type_id UUID NOT NULL REFERENCES leave_types(id) ON DELETE CASCADE,
  period_year INTEGER NOT NULL, entitled NUMERIC(12,2) NOT NULL DEFAULT 0, used NUMERIC(12,2) NOT NULL DEFAULT 0,
  UNIQUE(tenant_id,employee_id,leave_type_id,period_year)
);

CREATE TABLE IF NOT EXISTS payroll_periods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, starts_on DATE NOT NULL, ends_on DATE NOT NULL, status TEXT NOT NULL DEFAULT 'draft',
  UNIQUE(tenant_id,code)
);
CREATE TABLE IF NOT EXISTS employee_compensation (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, effective_from DATE NOT NULL,
  basic_salary NUMERIC(14,2) NOT NULL DEFAULT 0, housing_allowance NUMERIC(14,2) NOT NULL DEFAULT 0,
  transport_allowance NUMERIC(14,2) NOT NULL DEFAULT 0, other_allowances NUMERIC(14,2) NOT NULL DEFAULT 0,
  UNIQUE(tenant_id,employee_id,effective_from)
);
CREATE TABLE IF NOT EXISTS payroll_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  payroll_period_id UUID NOT NULL REFERENCES payroll_periods(id) ON DELETE CASCADE, status TEXT NOT NULL DEFAULT 'draft',
  started_at TIMESTAMPTZ, completed_at TIMESTAMPTZ, totals JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS payroll_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  payroll_run_id UUID NOT NULL REFERENCES payroll_runs(id) ON DELETE CASCADE, employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  basic NUMERIC(14,2) NOT NULL DEFAULT 0, allowances NUMERIC(14,2) NOT NULL DEFAULT 0, overtime NUMERIC(14,2) NOT NULL DEFAULT 0,
  deductions NUMERIC(14,2) NOT NULL DEFAULT 0, gross NUMERIC(14,2) NOT NULL DEFAULT 0, net NUMERIC(14,2) NOT NULL DEFAULT 0,
  breakdown JSONB NOT NULL DEFAULT '{}'::jsonb, UNIQUE(payroll_run_id,employee_id)
);

CREATE TABLE IF NOT EXISTS compliance_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, document_type TEXT NOT NULL,
  document_number TEXT, issued_at DATE, expires_at DATE, status TEXT NOT NULL DEFAULT 'active', metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_compliance_documents_expiry ON compliance_documents(tenant_id,expires_at);

CREATE TABLE IF NOT EXISTS vacancies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, title TEXT NOT NULL, title_ar TEXT, organization_id UUID REFERENCES organizations(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'draft', requirements JSONB NOT NULL DEFAULT '{}', created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(tenant_id,code)
);
CREATE TABLE IF NOT EXISTS candidates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL, email TEXT, phone TEXT, profile JSONB NOT NULL DEFAULT '{}', source TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  vacancy_id UUID NOT NULL REFERENCES vacancies(id) ON DELETE CASCADE, candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  stage TEXT NOT NULL DEFAULT 'applied', score NUMERIC(6,2), metadata JSONB NOT NULL DEFAULT '{}', UNIQUE(vacancy_id,candidate_id)
);

CREATE TABLE IF NOT EXISTS expenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, amount NUMERIC(14,2) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'SAR', category TEXT NOT NULL, expense_date DATE NOT NULL, receipt_url TEXT,
  status TEXT NOT NULL DEFAULT 'draft', payload JSONB NOT NULL DEFAULT '{}', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS travel_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, destination TEXT NOT NULL,
  starts_on DATE NOT NULL, ends_on DATE NOT NULL, estimated_cost NUMERIC(14,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft', payload JSONB NOT NULL DEFAULT '{}', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE, name TEXT NOT NULL, mime_type TEXT NOT NULL,
  storage_key TEXT NOT NULL, checksum TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS workflow_definitions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, name TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, active BOOLEAN NOT NULL DEFAULT true,
  definition JSONB NOT NULL, UNIQUE(tenant_id,code,version)
);
CREATE TABLE IF NOT EXISTS notification_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, title_template TEXT NOT NULL, body_template TEXT NOT NULL, channel TEXT NOT NULL DEFAULT 'in_app',
  UNIQUE(tenant_id,code,channel)
);

CREATE TABLE IF NOT EXISTS performance_cycles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL, starts_on DATE NOT NULL, ends_on DATE NOT NULL, status TEXT NOT NULL DEFAULT 'draft', settings JSONB NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS performance_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  cycle_id UUID NOT NULL REFERENCES performance_cycles(id) ON DELETE CASCADE, employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  reviewer_employee_id UUID REFERENCES employees(id) ON DELETE SET NULL, status TEXT NOT NULL DEFAULT 'draft', score NUMERIC(6,2), answers JSONB NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS goals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, title TEXT NOT NULL, description TEXT,
  target NUMERIC(14,4), actual NUMERIC(14,4) DEFAULT 0, weight NUMERIC(8,4) DEFAULT 1, status TEXT NOT NULL DEFAULT 'active', due_on DATE
);
CREATE TABLE IF NOT EXISTS skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, name TEXT NOT NULL, category TEXT, UNIQUE(tenant_id,code)
);
CREATE TABLE IF NOT EXISTS employee_skills (
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, skill_id UUID NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  proficiency NUMERIC(5,2) NOT NULL DEFAULT 0, assessed_at DATE, PRIMARY KEY(employee_id,skill_id)
);
CREATE TABLE IF NOT EXISTS courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, title TEXT NOT NULL, language TEXT NOT NULL DEFAULT 'ar', duration_minutes INTEGER, compliance_code TEXT,
  UNIQUE(tenant_id,code)
);
CREATE TABLE IF NOT EXISTS learning_enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'assigned', progress NUMERIC(5,2) NOT NULL DEFAULT 0, completed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS surveys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'draft', questions JSONB NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS survey_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  survey_id UUID NOT NULL REFERENCES surveys(id) ON DELETE CASCADE, employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  answers JSONB NOT NULL DEFAULT '{}', submitted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  asset_tag TEXT NOT NULL, category TEXT NOT NULL, description TEXT, status TEXT NOT NULL DEFAULT 'available',
  assigned_employee_id UUID REFERENCES employees(id) ON DELETE SET NULL, assigned_at TIMESTAMPTZ, UNIQUE(tenant_id,asset_tag)
);
CREATE TABLE IF NOT EXISTS benefits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, name TEXT NOT NULL, provider TEXT, policy_number TEXT, metadata JSONB NOT NULL DEFAULT '{}', UNIQUE(tenant_id,code)
);
CREATE TABLE IF NOT EXISTS employee_benefits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, benefit_id UUID NOT NULL REFERENCES benefits(id) ON DELETE CASCADE,
  starts_on DATE NOT NULL, ends_on DATE, status TEXT NOT NULL DEFAULT 'active'
);
CREATE TABLE IF NOT EXISTS integration_connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  provider TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'disconnected', config JSONB NOT NULL DEFAULT '{}', last_sync_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS ai_audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL, agent TEXT NOT NULL, action TEXT NOT NULL,
  input_hash TEXT, output_summary TEXT, tool_name TEXT, approved BOOLEAN, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS analytics_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  event_name TEXT NOT NULL, entity_type TEXT, entity_id UUID, properties JSONB NOT NULL DEFAULT '{}', occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- Enterprise lifecycle, policy, accounting and workflow completion tables
CREATE TABLE IF NOT EXISTS employee_lifecycle_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  effective_on DATE NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_employee_lifecycle ON employee_lifecycle_events(tenant_id, employee_id, effective_on DESC);

CREATE TABLE IF NOT EXISTS employment_contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  contract_number TEXT NOT NULL, contract_type TEXT NOT NULL DEFAULT 'indefinite',
  starts_on DATE NOT NULL, ends_on DATE, probation_days INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft', salary_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  document_id UUID REFERENCES documents(id) ON DELETE SET NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, contract_number)
);
CREATE INDEX IF NOT EXISTS idx_contract_employee ON employment_contracts(tenant_id, employee_id, starts_on DESC);

CREATE TABLE IF NOT EXISTS employee_onboarding (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending', due_on DATE, checklist JSONB NOT NULL DEFAULT '[]'::jsonb,
  completed_at TIMESTAMPTZ, UNIQUE(tenant_id, employee_id)
);

CREATE TABLE IF NOT EXISTS employee_offboarding (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  termination_date DATE NOT NULL, reason_code TEXT, notes TEXT, status TEXT NOT NULL DEFAULT 'initiated',
  checklist JSONB NOT NULL DEFAULT '[]'::jsonb, final_settlement JSONB NOT NULL DEFAULT '{}'::jsonb,
  completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS leave_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  leave_type_id UUID NOT NULL REFERENCES leave_types(id) ON DELETE CASCADE,
  transaction_date DATE NOT NULL, quantity NUMERIC(12,2) NOT NULL,
  transaction_type TEXT NOT NULL CHECK (transaction_type IN ('accrual','usage','adjustment','carryover','reversal')),
  source_request_id UUID REFERENCES requests(id) ON DELETE SET NULL, notes TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_leave_transactions_employee ON leave_transactions(tenant_id,employee_id,leave_type_id,transaction_date DESC);

CREATE TABLE IF NOT EXISTS attendance_daily_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, work_date DATE NOT NULL,
  shift_id UUID REFERENCES shifts(id) ON DELETE SET NULL, first_in TIMESTAMPTZ, last_out TIMESTAMPTZ,
  worked_minutes INTEGER NOT NULL DEFAULT 0, late_minutes INTEGER NOT NULL DEFAULT 0, early_leave_minutes INTEGER NOT NULL DEFAULT 0,
  overtime_minutes INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'unprocessed', source TEXT NOT NULL DEFAULT 'engine',
  details JSONB NOT NULL DEFAULT '{}'::jsonb, UNIQUE(tenant_id,employee_id,work_date)
);
CREATE INDEX IF NOT EXISTS idx_attendance_daily_employee_date ON attendance_daily_records(tenant_id,employee_id,work_date DESC);

CREATE TABLE IF NOT EXISTS payroll_items_extended (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  payroll_run_id UUID NOT NULL REFERENCES payroll_runs(id) ON DELETE CASCADE, employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  earning_components JSONB NOT NULL DEFAULT '{}'::jsonb, deduction_components JSONB NOT NULL DEFAULT '{}'::jsonb,
  gross_amount NUMERIC(14,2) NOT NULL DEFAULT 0, statutory_deductions NUMERIC(14,2) NOT NULL DEFAULT 0,
  net_amount NUMERIC(14,2) NOT NULL DEFAULT 0, employer_cost NUMERIC(14,2) NOT NULL DEFAULT 0,
  calculation_version TEXT NOT NULL DEFAULT '1', UNIQUE(payroll_run_id,employee_id)
);

CREATE TABLE IF NOT EXISTS statutory_rule_sets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, jurisdiction TEXT NOT NULL DEFAULT 'SA', effective_from DATE NOT NULL, effective_to DATE,
  version TEXT NOT NULL, rules JSONB NOT NULL DEFAULT '{}'::jsonb, status TEXT NOT NULL DEFAULT 'draft',
  UNIQUE(tenant_id,code,version)
);

CREATE TABLE IF NOT EXISTS accounting_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, name TEXT NOT NULL, account_type TEXT NOT NULL, parent_id UUID REFERENCES accounting_accounts(id) ON DELETE SET NULL,
  UNIQUE(tenant_id,code)
);
CREATE TABLE IF NOT EXISTS journal_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  entry_number TEXT NOT NULL, entry_date DATE NOT NULL, source_type TEXT, source_id UUID, status TEXT NOT NULL DEFAULT 'draft',
  description TEXT, posted_at TIMESTAMPTZ, UNIQUE(tenant_id,entry_number)
);
CREATE TABLE IF NOT EXISTS journal_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  journal_entry_id UUID NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE, account_id UUID NOT NULL REFERENCES accounting_accounts(id) ON DELETE RESTRICT,
  description TEXT, debit NUMERIC(14,2) NOT NULL DEFAULT 0, credit NUMERIC(14,2) NOT NULL DEFAULT 0,
  employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  CHECK (debit >= 0 AND credit >= 0 AND NOT (debit > 0 AND credit > 0))
);
CREATE INDEX IF NOT EXISTS idx_journal_entries_source ON journal_entries(tenant_id,source_type,source_id);

CREATE TABLE IF NOT EXISTS workflow_instances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  workflow_code TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id UUID, status TEXT NOT NULL DEFAULT 'running',
  current_step INTEGER NOT NULL DEFAULT 0, context JSONB NOT NULL DEFAULT '{}'::jsonb, started_at TIMESTAMPTZ NOT NULL DEFAULT now(), completed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS workflow_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  instance_id UUID NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE, step_index INTEGER NOT NULL,
  task_type TEXT NOT NULL, assignee_user_id UUID REFERENCES users(id) ON DELETE SET NULL, assignee_employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'pending', due_at TIMESTAMPTZ, payload JSONB NOT NULL DEFAULT '{}'::jsonb, completed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_workflow_tasks_assignee ON workflow_tasks(tenant_id,assignee_user_id,status);

CREATE TABLE IF NOT EXISTS compliance_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID REFERENCES employees(id) ON DELETE SET NULL, rule_code TEXT NOT NULL, severity TEXT NOT NULL DEFAULT 'medium',
  status TEXT NOT NULL DEFAULT 'open', due_on DATE, evidence JSONB NOT NULL DEFAULT '{}'::jsonb, resolved_at TIMESTAMPTZ,
  resolved_by UUID REFERENCES users(id) ON DELETE SET NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_compliance_cases_open ON compliance_cases(tenant_id,status,due_on);

-- Talent, performance, learning and engagement completion tables
CREATE TABLE IF NOT EXISTS recruitment_interviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  application_id UUID NOT NULL REFERENCES applications(id) ON DELETE CASCADE, interviewer_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  scheduled_at TIMESTAMPTZ NOT NULL, mode TEXT NOT NULL DEFAULT 'online', meeting_url TEXT, status TEXT NOT NULL DEFAULT 'scheduled',
  score NUMERIC(6,2), feedback JSONB NOT NULL DEFAULT '{}', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_recruitment_interviews_app ON recruitment_interviews(tenant_id,application_id,scheduled_at);

CREATE TABLE IF NOT EXISTS performance_reviewers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  review_id UUID NOT NULL REFERENCES performance_reviews(id) ON DELETE CASCADE, reviewer_employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  relationship TEXT NOT NULL DEFAULT 'manager', status TEXT NOT NULL DEFAULT 'pending', scores JSONB NOT NULL DEFAULT '{}', comments TEXT,
  submitted_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS learning_paths (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code TEXT NOT NULL, name TEXT NOT NULL, description TEXT, required BOOLEAN NOT NULL DEFAULT false, UNIQUE(tenant_id,code)
);
CREATE TABLE IF NOT EXISTS learning_path_courses (
  learning_path_id UUID NOT NULL REFERENCES learning_paths(id) ON DELETE CASCADE, course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  position INTEGER NOT NULL DEFAULT 0, required BOOLEAN NOT NULL DEFAULT true, PRIMARY KEY(learning_path_id,course_id)
);
CREATE TABLE IF NOT EXISTS employee_learning_paths (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE, learning_path_id UUID NOT NULL REFERENCES learning_paths(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'assigned', progress NUMERIC(5,2) NOT NULL DEFAULT 0, assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(), completed_at TIMESTAMPTZ,
  UNIQUE(tenant_id,employee_id,learning_path_id)
);
CREATE TABLE IF NOT EXISTS survey_campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  survey_id UUID NOT NULL REFERENCES surveys(id) ON DELETE CASCADE, starts_at TIMESTAMPTZ, ends_at TIMESTAMPTZ,
  anonymous BOOLEAN NOT NULL DEFAULT false, audience JSONB NOT NULL DEFAULT '{}', status TEXT NOT NULL DEFAULT 'draft'
);
CREATE TABLE IF NOT EXISTS engagement_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  metric_code TEXT NOT NULL, period_start DATE NOT NULL, period_end DATE NOT NULL, value NUMERIC(12,4) NOT NULL, dimensions JSONB NOT NULL DEFAULT '{}',
  UNIQUE(tenant_id,metric_code,period_start,period_end)
);

-- AI knowledge, retrieval and agent execution audit
CREATE TABLE IF NOT EXISTS ai_knowledge_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  title TEXT NOT NULL, source_type TEXT NOT NULL, source_key TEXT, checksum TEXT,
  content TEXT NOT NULL, metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS ai_knowledge_chunks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_id UUID NOT NULL REFERENCES ai_knowledge_documents(id) ON DELETE CASCADE,
  chunk_index INTEGER NOT NULL, content TEXT NOT NULL, metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  embedding JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(document_id,chunk_index)
);
CREATE INDEX IF NOT EXISTS idx_ai_knowledge_documents_tenant ON ai_knowledge_documents(tenant_id,updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_knowledge_chunks_document ON ai_knowledge_chunks(document_id,chunk_index);
CREATE TABLE IF NOT EXISTS ai_agent_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL, agent_code TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'running', input JSONB NOT NULL DEFAULT '{}', output JSONB,
  error TEXT, started_at TIMESTAMPTZ NOT NULL DEFAULT now(), completed_at TIMESTAMPTZ
);

-- Leave policy controls for configurable entitlement and approval rules
ALTER TABLE leave_types ADD COLUMN IF NOT EXISTS carryover_limit NUMERIC(12,2) NOT NULL DEFAULT 0;
ALTER TABLE leave_types ADD COLUMN IF NOT EXISTS minimum_unit NUMERIC(8,2) NOT NULL DEFAULT 1;
ALTER TABLE leave_types ADD COLUMN IF NOT EXISTS maximum_consecutive_days NUMERIC(8,2);
ALTER TABLE leave_types ADD COLUMN IF NOT EXISTS allow_negative_balance BOOLEAN NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS document_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE, version_no INTEGER NOT NULL,
  storage_key TEXT NOT NULL, checksum TEXT NOT NULL, mime_type TEXT NOT NULL,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, document_id, version_no)
);
CREATE TABLE IF NOT EXISTS document_signatures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE, signer_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  signer_employee_id UUID REFERENCES employees(id) ON DELETE SET NULL, status TEXT NOT NULL DEFAULT 'pending',
  requested_at TIMESTAMPTZ NOT NULL DEFAULT now(), signed_at TIMESTAMPTZ, provider_reference TEXT
);
CREATE TABLE IF NOT EXISTS notification_preferences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, notification_type TEXT NOT NULL,
  in_app BOOLEAN NOT NULL DEFAULT true, email BOOLEAN NOT NULL DEFAULT false, push BOOLEAN NOT NULL DEFAULT false,
  UNIQUE(tenant_id,user_id,notification_type)
);
CREATE TABLE IF NOT EXISTS security_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL, event_type TEXT NOT NULL, severity TEXT NOT NULL DEFAULT 'info',
  ip_address INET, user_agent TEXT, metadata JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_security_events_tenant_created ON security_events(tenant_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_created ON notifications(tenant_id,recipient_user_id,created_at DESC);

-- API idempotency and request tracing for safe retries of mutating operations.
CREATE TABLE IF NOT EXISTS api_idempotency_keys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  idempotency_key TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  response_status INTEGER NOT NULL,
  response_body JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  UNIQUE(tenant_id,user_id,idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_api_idempotency_expiry ON api_idempotency_keys(expires_at);

CREATE TABLE IF NOT EXISTS api_request_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES tenants(id) ON DELETE SET NULL,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  request_id TEXT NOT NULL,
  method TEXT NOT NULL,
  route TEXT NOT NULL,
  status_code INTEGER,
  duration_ms INTEGER,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_api_request_logs_tenant_created ON api_request_logs(tenant_id,created_at DESC);
