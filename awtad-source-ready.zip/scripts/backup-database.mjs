import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';

const url = process.env.DATABASE_URL;
if (!url) throw new Error('DATABASE_URL is required');
const outputDir = process.env.AWTAD_BACKUP_DIR || './backups';
await fs.mkdir(outputDir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const output = path.resolve(outputDir, `awtad-${stamp}.dump`);
const child = spawn('pg_dump', ['--format=custom','--no-owner','--no-privileges','--file',output,url], { stdio: 'inherit' });
child.on('error', (error) => { throw new Error(`pg_dump could not start: ${error.message}`); });
child.on('exit', (code) => process.exit(code ?? 1));
