import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const run = (command, args) => {
  const r = spawnSync(command, args, { stdio: 'inherit', shell: false });
  if (r.error) throw r.error;
  if (r.status !== 0) process.exit(r.status ?? 1);
};

const nodeMajor = Number(process.versions.node.split('.')[0]);
if (nodeMajor !== 22) {
  console.error(`verify: expected Node 22.x, found ${process.version}`);
  process.exit(1);
}

if (!existsSync('node_modules')) {
  console.error('verify: dependencies are not installed. Run `npm ci` (preferred) or `npm install` first.');
  process.exit(2);
}

console.log('verify: running domain/config/security checks');
run(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'test:all']);
console.log('verify: running TypeScript');
run(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'typecheck']);
console.log('verify: running production build');
run(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'build']);
console.log('verify: PASS');
