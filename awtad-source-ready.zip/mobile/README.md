# Awtad Mobile

React Native / Expo source boundary for the employee and manager mobile experience.

The mobile client must authenticate against the same tenant-scoped API and must never embed service credentials. Production push, biometric, camera, location and document-storage providers remain configuration/adapters rather than hard-coded secrets.
