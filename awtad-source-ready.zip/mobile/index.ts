export type MobileSession={userId:string;tenantId:string;accessToken:string};
export type AttendanceAction='clock_in'|'clock_out';
export type MobileApiClient={request<T>(path:string,init?:RequestInit):Promise<T>};
export function attendancePath(action:AttendanceAction){return `/api/attendance?action=${action}`;}
